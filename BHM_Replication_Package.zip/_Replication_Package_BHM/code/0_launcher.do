
clear all
set varabbrev off

*===============================================================================
*	Folder locations
*===============================================================================

*** SET YOUR OWN PATHS HERE 
* Input path to CASD raw data here
global rawdatadir 		"\\casd.fr\casdfs\Projets\FISCENT\Data"

* Input path to CASD public folder where you can store your project 
local publicpath "C:\Users\Public\Documents"
		
*** Raw source  
cap mkdir "`publicpath'/Raw_dta_confidential"
cap mkdir "`publicpath'/Raw_publicly_available"

global source_conf 		"`publicpath'/Raw_dta_confidential"
global source_publ 		"`publicpath'/Raw_publicly_available"

*** Extra subfolders for raw confidential 
foreach folder in ficusfare{
	cap mkdir 			"$source_conf/`folder'"
}

*** Project folder 
global projectfolder 	"`publicpath'/LegalStatus"		

*** General architecture 
foreach folder in code data log_file result{
	cap mkdir 		"$projectfolder/`folder'"
	global `folder' "$projectfolder/`folder'"
}

*** Directory for data 
foreach folder in source temp output{
	cap mkdir 		"$projectfolder/data/`folder'"
	global `folder' "$projectfolder/data/`folder'"
}

*** Directory for results
foreach name in coeff gcoeff {
	cap mkdir "$projectfolder/result/_`name'"
	global `name' "$projectfolder/result/_`name'"
}

*** Directory for own-ado file 
global ado "$projectfolder/code/_stataPrograms"
		
*===============================================================================
* Install specific stata ado files 
*===============================================================================

do "$ado/_programEventStudy/evstudydd.ado"
do "$ado/_programWinsor/winsor4.ado"
do "$ado/number_exporting/number_exporting.ado"

*===============================================================================
* Install stata packages
*===============================================================================

// foreach package in number_exporting winsor4 evstudydd reghdfe ftools gtools egenmore estout erepost moremata splitvallabels labutil asdoc{
// 	ssc install `package', replace 
// }

*===============================================================================
* log file 
*===============================================================================

cap log close
local datetime : di %tcCCYY.NN.DD!-HH.MM.SS `=clock("$S_DATE $S_TIME", "DMYhms")'
local logfile "$projectfolder/log_file/`datetime'.log.txt"
log using "`logfile'", text


*===============================================================================
* Define fixed effects, cluster and prepare FE output for tables
*===============================================================================

*** Period including pre-sample & post-sample analysis 	
global fyear_all 	"2000"
global lyear_all 	"2017"

*** Period restricted to sample analysis 	
global fyear_sample "2004"
global lyear_sample "2012"

*** FE + Cluster
global cluster 		"naf5"
global fe_reg 		"naf5 naf2year c.s_sas#i.year"
global sizeyr 		"c.size#i.year"

*** Specify the list of models for the tables 
global fe_spec1 "naf5 naf2year"
global fe_spec2 "$fe_reg"
global fe_spec3 "$fe_reg geoyear"
global fe_nspec = 3

*** Variable definitions
global SIZE 		"log_Mat_p03aAll"
global s_sasDEF 	"s_sas_p03aAll"
global exposure 	"Meq_at_p03a04"
global geo 			"dep"		

*** Main LHS 
global K3clean 	"Ktot3_e_5it"
global Eclean 	"equity1_e_5it"
global clean 	"_e_5it"

* Needed when we want to select variables in the dataset
global fe_reg_list " ${exposure} naf5 naf2year year s_sas geoyear"  

*** list of FE for tables
	global listFE ///				
		estfe . est* , labels( ///
		naf5 "\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Industry" ///
		year 				"\hspace{1.5em}Year" ///
		naf2year 			"\hspace{1.5em}Industry (2-digit)\(\times\)Year" ///
		geoyear		 		"\hspace{1.5em}County\(\times\)Year" ///	
		year#quintile_s_sas  "\textit{Controls} \\ \hspace{1.5em}Pre-reform flexible share\(\times\)Year" ///
		year#c.s_sas  "\textit{Controls} \\ \hspace{1.5em}Pre-reform flexible share\(\times\)Year" ///		
		year#c.size  		"\hspace{1.5em}Average size\(\times\)Year" ///
		year#c.hhi_downstream	"\hspace{1.5em}HHI downstream\(\times\)Year" ///
		year#c.hhi_upstream		"\hspace{1.5em}HHI upstream\(\times\)Year" ///		
		year#c.hhi				"\hspace{1.5em}HHI focal\(\times\)Year" ///		
		year#c.net_trade_credit	"\hspace{1.5em}Trade credit\(\times\)Year" ///	
		year#c.auto				"\hspace{1.5em}Share auto-entrepreneur\(\times\)Year" ///			
		year#quintile_at	"\hspace{1.5em}Average entry size\(\times\)Year")
// 		return list	

*** Global for clean table 
	global tableClean_2 ///
		replace cells(b(fmt(%9.2g) star) se(fmt(%9.2g) par))  ///
		starlevels(* .1 ** .05 *** .01) ///
		varwidth(50) nolines label	///
		fragment mlabels(none) collabels(none) booktab   ///			
		nonotes nonumber /// 
		mgroups(\vspace{-.3cm}) keep(Z_post )	///
		nonotes stats(N, fmt(%12.0fc ) label("Observations")) 


*===============================================================================
* Programs specific to this project
*===============================================================================
		
capture program drop run_did
program define run_did
    syntax, lhs(string) rhs(string) filename(string)
    
    foreach var of local lhs {
        forvalues i = 1/$fe_nspec {
            eststo: reghdfe `var' `rhs', a(${fe_spec`i'}) cluster($cluster) nocons
            $trueobs
        }
    }
    quiet $listFE
    esttab using "$result/`filename'.tex", ///
        $tableEnvironment ///
        indicate(`r(indicate_fe)', labels($\checkmark$ ---))
end

*===============================================================================
* Run all the dofiles
*===============================================================================

do "$code/2_Dofile/00b_own_programs.do"

* Extract raw data 

/*
	CAREFUL, in the folder "1_Extraction" there are three sas files 
	needed to extract raw datasets that are too big for stata  
	
	All you need to do is to double click on the sas code 
	Change the path names (at the beginning of each sas code) for in the input and output path and run them
	
	If you CASD makes you change which SAS version to use, make sure to use SAS 9.4 (Francais) as some characters in the 
	early files of FICUS might not be handled correctly otherwise 
	
	Normally just double-clicking on the sas program should ensure it runs with no problem automatically 
	
	There are THREE sas codes to run:
	- sas_extract_acoss 
	- sas_extract_dads_postes
	- sas_extract_ficus_fare

*/

do "$code/1_Extraction/Extract_ficusfare.do"			

*** convert raw data 
do "$code/1_Extraction/Extract_lifi.do"					
do "$code/1_Extraction/Extract_sirene.do"				


*** Extract firm level variables 
do "$code/2_Dofile/100_Ficus_Extract_Data.do"			
do "$code/2_Dofile/100b_time_consistent_industry.do"	
do "$code/2_Dofile/100c_time_consistent_geography.do"	
do "$code/2_Dofile/100d_Table_input_output.do"			

*** Create firm level variables 
do "$code/2_Dofile/101_Ficus_Clean_Data_clean.do"		

*** Construct new and incumbent firms sample 
do "$code/2_Dofile/110_Reform_Construct_Sample.do" 		

*** Construct industry level variables 
do "$code/2_Dofile/111_Industry_characteristics.do" 	
do "$code/2_Dofile/112_Assemble_all.do" 			


*** SINE
do "$code/2_Dofile/120_SINE_Extract_Assemble.do"		

*** Bylaws 
*do "$code/130_Clauses_Assemble_Data.do" // Clauses data will be made open source
do "$code/2_Dofile/131_Clauses_Clean_Data.do"		

*** Shareholders 
*do "$code/132_Shareholders_Clean_Data.do" // Shareholder data will be made open source
do "$code/2_Dofile/133_Shareholders_Construct_Variables.do" 

*** Assemble all 
do "$code/2_Dofile/134_Merge_Bylaws_Ficus.do"			

*** Run regressions in the paper.  
do "$code/2_Dofile/300_Tables_paper.do"					
do "$code/2_Dofile/301_Graphs.do"					
do "$code/2_Dofile/302_Appendix.do"

* Erase all files in the temp folder
local files : dir "$temp" files "*"
foreach f of local files {
	capture erase "$temp/`f'"
	if _rc di as error "Could not delete: $temp/`f'"
}
 
* End log 
di "End date and time: $S_DATE $S_TIME"
log close 

