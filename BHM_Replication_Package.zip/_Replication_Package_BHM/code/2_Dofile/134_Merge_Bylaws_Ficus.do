
/*==============================================================================
Output: Merged data bylaws + ficus at
- document level
- firm-year level
- firm level
==============================================================================*/

* List of provisions
use "$temp/bylaws_doc_01", replace
ds siren year year0 id lockup_length lockup_date capital nb_parts prix_part pct*, not
global list_features0 `r(varlist)'

ds siren year year0 id lockup_length lockup_date capital nb_parts prix_part pct*, not
global list_features `r(varlist)'

* Other dummies 
global dummies has_shceo male_ceo is_french_ceo

global sample sample_shareholders sample_ceo sample_provisions sample_capital

*Continuous variables
global continuous frac_company fraction_equity_ceo age_ceo n_shareholders ///
dept_diversity all_male_shareholders all_female_shareholders ///
male_female_shareholders frac_female all_french_shareholders ///
all_foreign_shareholders french_foreign_shareholders frac_nonfr ///
frac_shareholders_outofdep frac_shares_outofdep diversity_family ///
hhi_shares_raw hhi_shares_adj majority_shareholder majority_shareholder_pooled ///
shareholder_age_sd capital nb_parts prix_part top_family_share

*===============================================================================
* DOCUMENT-LEVEL BYLAWS (provisions + shareholders/CEO characteristics)
*===============================================================================

*** Merge CEO and shareholders characteristics with provisions

	* CEO characteristics
	use "$output/ceo_characteristics_clean", clear
	gen sample_ceo = 1
	* make sure siren is 9 digit string 
	tostring siren,replace
	replace siren = substr("0000"+siren,-9,.)

	* Shareholder characteristics
	merge 1:1 year0 id using "$output/shareholders_characteristics_clean", update // about 5% of obs don't have shareholders info
	gen sample_shareholders = 1 if inlist(_merge,2,3)
	drop _merge

	* Provisions
	merge 1:1 year0 id using "$temp/bylaws_doc_01", update // about 50% of docs don't have ceo/shareholders info
	gen sample_provisions = 1 if inlist(_merge,2,3)
	drop _merge

	* SAS status (sas is already there for firms coming from the provisions sample, but not for firms from the CEO and shareholders sample only)
	merge m:1 siren using "$temp/dummy_sas", keep(1 3 4 5) keepusing(sas_var0) update nogen

*** Prepare variables
	drop pct_*

	* Cumulative dividend is a form of preferred claim in liquation
	replace ms_liq = 1 if pref_div_cumul==1	// 

	* Different types of diff. CF rights
	qui foreach var in ms_div ms_liq ms_cashout warrant {
		replace `var' = 0 if `var'==.
	}

	* Dummy any diff. CF rights
	gen pref_cf_any = max( ms_div, ms_liq, ms_cashout, warrant)
	lab var pref_cf_any "Any diff. CF rights"
	* Dummy diff. CF rights for the CEO (assuming warrants are granted to CEO)
	gen pref_cf_ceo = max( max( ms_div, ms_liq, ms_cashout)*has_shceo, warrant) if has_shceo<.
	lab var pref_cf_ceo "Diff. CF rights for CEO"

	* Other provisions about control
	gen ms_control = max( ms_board, ms_ceo, ms_vot)
	qui foreach x in control board ceo vot {
		gen pref_`x' = ms_`x'
		replace pref_`x' = 0 if ms_`x'==.
	}

	* Anti-dilution provisions (very rare) are a form of preemptive rights on new shares
	replace prio_issuance = 1 if antidilut==1

	* "Right Of First Offer" and "Right of First Refusal" resemble preemptive rights when other shareholders sell their shares (ROFR and ROFO are rare anyway)
	replace preemp = 1 if rofr==1 | rofo==1

	* Ownership provisions specific to multiple share classes
	replace ms_preemp = 0 if ms_preemp==.
	replace ms_transfer_approval = 0 if ms_transfer_approval==.
	replace ms_exclusion = 0 if ms_exclusion==.

	* Do we observe share capital? 
	gen sample_capital = !missing(capital)

	*Add new features
	global list_features $list_features0 pref_cf_ceo pref_cf_any pref_control pref_board pref_ceo pref_vot

save "$temp/bylaws_doc", replace

*===============================================================================
* BYLAWS AT FIRM-YEAR LEVEL
*===============================================================================

* Provisions at the document level
use "$temp/bylaws_doc", clear

* Copy labels
foreach var in $list_features $dummies $continuous $sample {
	local lab`var' : variable label `var'
}

* Collapse by firm-year
gcollapse (max) $list_features $dummies $sample sas_var0  /// 
(mean) $continuous, by(siren year year0)

* Paste labels
foreach var in $list_features $dummies $continuous $sample {
	label var `var' "`lab`var''"
}

save "$temp/bylaws_firmyear", replace

*===============================================================================
* BYLAWS AT FIRM LEVEL
*===============================================================================

use "$temp/bylaws_firmyear", clear

* Define "cumulative" features
*	=1 if the feature appears at least once up until the current year
*	=0 otherwise
gsort siren year
foreach var in $list_features $dummies {
	qui gen `var'_ = .
	qui by siren: replace `var'_ = max(`var'_[_n-1], `var')
	drop `var'
}

foreach var in $continuous $sample {
	rename `var' `var'_ 
}

* Reshape wide with 1 obs per firm
gen age = year-year0
drop year
reshape wide *_, i(siren year0) j(age)

foreach var in $list_features $dummies $continuous {
	forval t = 1/3 {
		local tt = `t'-1
		qui replace `var'_`t' = `var'_`tt' if `var'_`t'==.
	}
}

save "$temp/bylaws_firm", replace



*===============================================================================
* Extract subset of accounting variables 
*===============================================================================

* Ficus data (1 obs per new firm)
use siren year naf5 naf2 dep ze2010 ///
	using "$temp/newfirms01", replace

* Rename creation year because it sometimes differ that in bylaws data
rename year year0_ficus

* Save
save "$temp/ficus_fare_new", replace


*===============================================================================
* MERGE BYLAWS + FICUS
*===============================================================================

foreach level in doc firm {  
	
// 	local level firm 
	* Bylaws at document level, firm-year level, or firm level
	use "$temp/bylaws_`level'", clear
	
	* Merge with FICUS
	merge m:1 siren using "$temp/ficus_fare_new", update 
	gen sample_ficus = 1 if inlist(_merge,2,3)
	drop _merge
	
	* Creation year might differ in ficus versus bylaws data
	lab var year0_ficus "Creation year in Ficus sample"
	lab var year0 		"Creation year in bylaws sample"
	
	* Merge with VC
	/*
		NB: Crunchbase is a commercial dataset, hence cannot be shared freely 
	*/
	merge m:1 siren using "$source_publ/vc_backed_firm", keep(1 3) nogen
	rename vc vc_siren
	lab var vc_siren "VC-backed (based on shareholders)"
	merge m:1 siren using "$source_publ/crunchbase", keep(1 3)
	gen vc_cb = _merge==3
	lab var vc_cb "VC-backed (based on Crunchbase)"
	drop _merge
	gen vc = (vc_siren==1 | vc_cb==1) if vc_siren<. | vc_cb<.
	lab var vc "VC-backed (based on shareholders+Crunchbase)"
	
	* Industry-level info from FICUS
	merge m:1 naf5 using "$output/indvolat_naf5", keep(1 3) nogen update
	
	* Industry-level info from SINE
	merge m:1 naf5 using "$output/innovative_naf5", keep(1 3) nogen update
	
	* Merge with SINE
	merge m:1 siren using "$output/sine_final", keep(1 3) nogen update keepusing(year0_sine educhigher grandeeco objectif serial age*)
	
	drop if siren == ""
	save "$output/bylaws_`level'_ficus", replace

}
*
