
*** LIST OF OUTCOMES WE WANT TO USE 
	global Y_list "Y Ktot L equity eqall at net_trade_credit ni_at div_at"
	
*===============================================================================
* WORKING SAMPLE WITH LEADS AND LAGS
*===============================================================================
	
use "$temp/ficus_fare_01ageff", clear

*** Immediately compute the t-1 variable before taking the sample period to 2004
	gegen firmid = group(siren)
	sort firmid year 
	xtset firmid year 
	
*** Time varying legal status
	gen sas_var				= floor(cj_var/100)==57
	rename subsidiary sub 
	
*** Total employees at year 0 
	gen eff0 		= eff // used for extra filter

*** Lead for other variables 	
	foreach var of varlist sas_var $Y_list {
		di in red "`var'"
		if inlist("`var'","sas_var"){
			local tlist  "0 1 2 3"
		}				
		if inlist("`var'","equity","eqall","net_trade_credit","ni_at","div_at"){
			local tlist  "1 3"
		}	
		if inlist("`var'","Ktot","Y"){
			local tlist  "0 1 2 3 4 5"
		}			
		if inlist("`var'","at","L"){
			local tlist  "1 3"
		}			
		qui foreach t in `tlist' { //  
			* t-year forward
			gen `var'`t' 	= F`t'.`var'
			* including extensive margin
			if "`var'" != "sas_var" { // extensive margin does not make sense for sas
			gen `var'`t'_e 	= `var'`t'
			recode `var'`t'_e . = 0			
		}
		}
		drop `var'
	}	

	tempfile temp 
	save `temp'

*===============================================================================
* New firms
*===============================================================================

use `temp', clear

*** RESTRICT PANEL
	* keep 1 obs per firm
	keep if age==0

	// Filters
	* Keep to pre / post time period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}
	
	* drop if already large at entry
	drop if eff0>50 & eff0<.

	* keep if survive 1 year
	keep if Y1<.

	* bring local labor market code 
	merge m:1 commune using "$temp/bassin_emploi2010",nogen keep(3)
	
save "$temp/newfirms01", replace


*===============================================================================
* Incumbents
*===============================================================================
{
	
use `temp', clear
	
*** Filters
	* keep firms aged 5-10 years
	keep if age>=5 & age<=10

	* Keep to pre / post time period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}

	* drop largest firms (p99 of eff0 = 60)
	drop if eff0>50 & eff0<.
	
*** Outcomes: growth
	local var "Ktot"
	local t 3
	foreach START in 0 1 {
		* Log growth rate 
		gen gl`START'_`var'`t' = log(`var'`t'_e / `var'`START'_e) 
		* Normal growth rate  
		gen g`START'_`var'`t'  = (`var'`t'_e / `var'`START'_e) 	
	}
	
	* bring local labor market code 
	merge m:1 commune using "$temp/bassin_emploi2010",nogen keep(3)
	
save "$temp/incumbents01", replace

	
}
*

*===============================================================================
* Extract legal form for merge with bylaws 
*===============================================================================
	
use siren sas sas_var* using "$temp/newfirms01", clear
egen eversas = rowmax(sas_var0 sas_var1 sas_var2 sas_var3)
keep siren sas eversas
save "$output/dummy_sas", replace	

