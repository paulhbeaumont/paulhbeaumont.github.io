
*===============================================================================
*===============================================================================
* Descriptive statistics Tables  
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Table 1: Summary stat 
*-------------------------------------------------------------------------------
{
	
	use sas_var0 equity3${clean} Ktot3* L3${clean} Y3${clean} ${exposure} div_at3 ///
		net_trade_credit3 siren year  L3 Y3 Ktot2* Ktot1${clean} at3${clean} ///
		using "$output/new_inc_workingsample_th0" if year<2008, clear
	
	rename at3${clean} at3
	
	gen survival3 = Y3 > 0 & Y3 <.	
	gen capex3_K 	= (Ktot3 - Ktot2)/at3
	gen laborshare	= L3/Y3
	gen Y_at3 = Y3/at3
	
*** List of variables to summarize
	global vars_to_summarize "Ktot3${clean} L3${clean} Y3${clean} equity3${clean} at3 survival3 laborshare Y_at3 capex3_K net_trade_credit3"
	
	foreach var in $vars_to_summarize {
		winsor4 `var', method(winsor) level(1) outlier(tail) 
	}
	
*** Produce table  
	eststo clear
	eststo overall: estpost tabstat ${vars_to_summarize}, columns(statistics) statistics(mean sd p25 p50 p75)

*** label variables 
	label var equity3${clean}	"Equity"
	label var at3 				"Assets"	
	label var Ktot3${clean} 	"Capital"
	label var L3${clean} 		"Wage bill"
	label var Y3${clean} 		"Revenues"
	label var survival3 		"Survival"
	label var Y_at3 			"Revenues/Assets"
	label var div_at3 			"Dividends/Assets"
	label var capex3_K 			"Capex"
	label var net_trade_credit3 "Net trade credit"
	label var laborshare		"Wage bill/revenues"

*** latex table for paper
	#delimit ;
	esttab using "$result/summary_statistics.tex",
		cells("mean(fmt(%9.2fc) label(Mean)) sd(fmt(%9.2fc) label(Std.\ Dev.)) p25(fmt(%9.2fc)) p50(fmt(%9.2fc) label(Median)) p75(fmt(%9.2fc))")
		nostar nonumbers nomtitle label booktabs width(50em)
		substitute("\_" "_") stats(N, fmt(%12.0fc ) label("Observations"))
		replace;	
	#delimit cr
}

*-------------------------------------------------------------------------------
* Table 2: Share of Firms With Tailored Bylaws (%)
*-------------------------------------------------------------------------------
{
*--------------
* Data
*--------------

/* Sample: 1 obs = 1 firm. 
	Use provisions defined as the max over all years, i.e., the cumulative features in year 3
*/

use "$output/bylaws_firm_ficus", clear	// constructed in 134_Merge_Bylaws_Ficus.do

* Keep provisions in year 3, since they are cumulative over time (max by siren)
* Keep if we observe the provisions at least once
gen any_provisions = max(sample_provisions_0,sample_provisions_1, ///
sample_provisions_2,sample_provisions_3)
keep if any_provisions==1
drop *_0 *_1 *_2
foreach var_3 of varlist *_3 {	// loop over provisions
	local var = substr( "`var_3'", 1, length("`var_3'")-2)	// remove suffix "_3"
	rename `var_3' `var'
}

* We remove firms not Ficus-Fare 
keep if sample_ficus==1
merge 1:1 siren using "$temp/dummy_sas", keep(1 3) keepusing(eversas) nogen 

*** Label the different provisions
	* Any deviation
	eststo clear
	label var any_deviation "Tailored bylaws"

	* Ownership
	gen pref_ownership = max(ms_transfer_approval,ms_preemp,ms_exclusion)
	gen any_ownership = max(prio_issuance,free,preemp,noncomp,exclusion,lockup,tag,drag,tagdrag,pref_ownership)

	lab var any_ownership  "\addlinespace\quad Tailored ownership rights"
	lab var prio_issuance  "\quad\quad Priority in share issuance"
	lab var preemp "\quad\quad Priority in share transfer"
	lab var free "\quad\quad Unrestricted share transfers"
	lab var noncomp "\quad\quad Non-compete"
	lab var exclusion "\quad\quad Shareholder exclusion"
	lab var pref_ownership "\quad\quad Class-specific ownership rights"
	lab var lockup "\quad\quad Lock-up period"
	lab var tag "\quad\quad Tag-along"
	lab var drag "\quad\quad Drag-along"

	* Governance
	gen any_governance = max(dg,suspension,ad_nutum,governance,pref_control)

	lab var any_governance "\addlinespace\quad Tailored control rights"
	lab var governance "\quad\quad Governance body"
	lab var dg "\quad\quad CEO can appoint executive officers"
	lab var suspension "\quad\quad Suspension of voting rights"
	lab var ad_nutum "\quad\quad Ad nutum CEO termination"
	lab var pref_control "\quad\quad Class-specific control rights"

	* Cash flow rights
	lab var pref_cf_any "\addlinespace\quad Tailored cash-flow rights"
	lab var warrant "\quad\quad Stock options"
	lab var ms_liq "\quad\quad Preferred liquidation rights"
	lab var ms_div "\quad\quad Preferred dividend rights"
	lab var ms_cashout "\quad\quad Class-specific cash-out rights"

	* VC backed
	replace vc = vc_siren==1 | vc_cb==1
	lab var vc "\addlinespace VC backed"

*** x100 to display stats in %
	foreach x of varlist any_deviation ///
		any_ownership prio_issuance preemp free noncomp exclusion lockup tag drag pref_ownership ///
		any_governance dg suspension ad_nutum governance pref_control ///
		pref_cf_any warrant ms_liq ms_div ms_cashout eversas vc {
		replace `x' = `x'*100
	}


*--------------
* Export coeff for paper 
*--------------

* Share of firms with a bylaw that deviates
qui sum any_deviation
number_exporting `r(mean)', name("$coeff/any_deviation") digits(1)

* Share of non VC-firms with a bylaw that deviates
qui sum any_deviation if vc==0
number_exporting `r(mean)', name("$coeff/any_deviation_noVC") digits(1)

* Gives existing shareholders the priority to purchase newly issued shares in order to maintain their ownership stake
qui sum prio_issuance
number_exporting `r(mean)', name("$coeff/prio_issuance") digits(1)
	
* Allowing unrestricted transfers	
qui sum free
number_exporting `r(mean)', name("$coeff/free") digits(1)

* Existing shareholders have priority rights to acquire the shares of selling shareholders
qui sum preemp
number_exporting `r(mean)', name("$coeff/preemp") digits(1)

* Non-compete provisions	
qui sum noncomp
number_exporting `r(mean)', name("$coeff/noncomp") digits(1)

* Exclusion provisions
qui sum exclusion
number_exporting `r(mean)', name("$coeff/exclusion") digits(1)

* Class-specific ownership rights 
qui sum pref_ownership
number_exporting `r(mean)', name("$coeff/pref_ownership") digits(1)

* Lockup period 
qui sum lockup
number_exporting `r(mean)', name("$coeff/lockup") digits(1)

* Tag-along clauses
qui sum tag
number_exporting `r(mean)', name("$coeff/tag") digits(1)

* Drag-along clauses
qui sum drag
number_exporting `r(mean)', name("$coeff/drag") digits(1)

** Tailored control rights and governance arrangements
qui sum any_governance
number_exporting `r(mean)', name("$coeff/any_governance") digits(1)

* Creation of boards or other intermediary governance bodies 
qui sum governance
number_exporting `r(mean)', name("$coeff/governance") digits(1)

* CEO is granted the authority to appoint executive officers
qui sum dg
number_exporting `r(mean)', name("$coeff/dg") digits(1)

* Ad nutum termination provision
qui sum ad_nutum
number_exporting `r(mean)', name("$coeff/ad_nutum") digits(1)

* Provisions for suspending the voting rights of certain shareholders under specific conditions
qui sum suspension
number_exporting `r(mean)', name("$coeff/suspension") digits(1)

* Issuing multiple classes of shares with differentiated voting rights or appointment rights for board members or the CEO
qui sum pref_control
number_exporting `r(mean)', name("$coeff/pref_control") digits(1)

** Tailored of cash-flow rights
qui sum pref_cf_any
number_exporting `r(mean)', name("$coeff/pref_cf_any") digits(1)

* Preferred shares granting preferred dividends paid before common dividends
qui sum ms_div
number_exporting `r(mean)', name("$coeff/ms_div") digits(1)
	
* Stock options 
qui sum warrant
number_exporting `r(mean)', name("$coeff/warrant") digits(1)

* Preferred liquidation rights
qui sum ms_liq
number_exporting `r(mean)', name("$coeff/ms_liq") digits(1)
	
* Priority rights over cash-out proceeds from IPOs or acquisitions
qui sum ms_cashout
number_exporting `r(mean)', name("$coeff/ms_cashout") digits(2)

	
*--------------
* Stats unconditional and conditional on VC
*--------------

*** Number of observations
	qui count
	local N_all : display %9.0gc r(N)
	qui count if vc==0
	local N_cond : display %9.0gc r(N)

	// List of variables
	local varlist any_deviation any_ownership prio_issuance free preemp noncomp exclusion pref_ownership lockup tag drag any_governance governance dg ad_nutum suspension pref_control pref_cf_any ms_div warrant ms_liq ms_cashout vc

	// Temporary dataset to store results
	tempname memhold
	tempfile results
	postfile `memhold' str100 varlabel fullsample conditional using `results'

	// Loop over variables to compute means
	foreach v of local varlist {
		local lab : variable label `v'
		quietly summarize `v'
		local mean_all = r(mean)

		quietly summarize `v' if vc==0
		local mean_cond = r(mean)

		post `memhold' ("`lab'") (`mean_all') (`mean_cond')
	}
	postclose `memhold'

	// Load the results and export to LaTeX format
	use `results', clear

	// Round for readability
	foreach col in fullsample conditional {
		gen r_`col' = round(`col', 0.01)
	}

	// Export to .tex
	file open texout using "$result/stats-features-vc.tex", write replace

	quietly {
		forvalues i = 1/`=_N' {
			local row_label = varlabel[`i']
			local mean1 = string(fullsample[`i'], "%9.2f")
			local mean2 = string(conditional[`i'], "%9.2f")
			file write texout "`row_label' & `mean1' & `mean2' \\" _n
		}
	}

	file write texout "\addlinespace\midrule\addlinespace" _n
	file write texout "Observations & `N_all' & `N_cond' \\" _n

	file close texout

}
*

*-------------------------------------------------------------------------------
* Table 3: Tailored Bylaws and Firms’ Characteristics
*-------------------------------------------------------------------------------
{
*--------------
* DATA
*--------------

* Sample: 1 obs = 1 doc.

* Bylaws
use "$output/bylaws_doc_ficus", clear

* Keep if the document has detected provisions, CEO characteristics, and shareholders characteristics
keep if sample_provisions==1
keep if sample_ceo==1
keep if sample_shareholders==1

* Only status, otherwise some clauses are not defined
keep if article == 1

* Number of shareholders
gen n_shareholders_topcoded10 = min(n_shareholders,10)

* External CEO
// lab var has_shceo "CEO is shareholder"
gen ext_ceo = 1-has_shceo

gen minus_top_family_share = -top_family_share

*--------------
* REGRESSIONS
*--------------

global RHS frac_shareholders_outofdep ext_ceo n_shareholders_topcoded10 dept_diversity minus_top_family_share innov_sector sd_gY

	local LHS any_deviation
	
	foreach var in $RHS {
		qui drop if `var'==.
	}
	qui gegen n_doc = sum(1), by(siren)
	gen inv_n_doc = 1/n_doc

	eststo clear
	qui foreach var in $RHS {
		eststo: reghdfe `LHS' `var' [aw=inv_n_doc], a(year0) vce(cluster siren)
		$trueobs
	}
	qui eststo: reghdfe `LHS' $RHS [aw=inv_n_doc], a(year0) vce(cluster siren)
	qui $trueobs
	
	** Shareholder characteristics 	
	lab var frac_shareholders_outofdep 	"\hspace{1.5em}\% Distant shareholders"
	lab var dept_diversity 				"\hspace{1.5em}Shareholder geog. dispersion"
	lab var minus_top_family_share 		"\hspace{1.5em}Non-family ownership"
	lab var ext_ceo 					"\hspace{1.5em}External CEO"
	lab var n_shareholders_topcoded10 	"\hspace{1.5em}Number of shareholders "

	** Firm characteristics 
	lab var innov_sector 				"\hspace{1.5em}Innovative sector"
	lab var sd_gY 						"\hspace{1.5em}Idiosyncratic volatility"
	
	estfe . est* , labels( ///
		year0	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Year of creation")
	return list	
		
	esttab using "$result/bylaws_firm_any_deviation.tex", nocons ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))
		
*** Economic magnitude
	* Effect of number of shareholders
	reghdfe any_deviation $RHS [aw=inv_n_doc], a(year0) vce(cluster siren)
	number_exporting _b[n_shareholders_topcoded10]*100, name("$coeff/nshareholder") digits(1)
	qui sum any_deviation 
	number_exporting _b[n_shareholders_topcoded10]/r(mean), name("$coeff/nshareholder_pct") digits(1) percent

	* Effect of shareholder dispersion
	reghdfe any_deviation $RHS [aw=inv_n_doc], a(year0) vce(cluster siren)
	number_exporting (_b[minus_top_family_share]*(.6))*100, name("$coeff/shareholder_concentration_pp") digits(1)
	number_exporting (_b[minus_top_family_share]), name("$coeff/shareholder_concentration_coeff") digits(1)	
	qui sum any_deviation  
	number_exporting (_b[minus_top_family_share]*(.6))/r(mean), name("$coeff/shareholder_concentration_pct") digits(1) percent
	number_exporting r(mean), name("$coeff/any_deviation_mean") digits(2)
	
}
*

*-------------------------------------------------------------------------------
* Table 4: Tailored Bylaws and Entrepreneurs’ Characteristics
*-------------------------------------------------------------------------------
{
*--------------
* DATA
*--------------

* Sample: 1 obs = 1 firm. 

* Bylaws 1 obs per firm with different years in columns
use "$output/bylaws_firm_ficus", clear	// constructed in 134_Merge_Bylaws_Ficus.do

* Keep provisions in year 3, since they are cumulative over time (max by siren)
* Keep if we observe the provisions at least once
gen any_provisions = max(sample_provisions_0,sample_provisions_1, ///
sample_provisions_2,sample_provisions_3)
keep if any_provisions==1
drop *_0 *_1 *_2
foreach var_3 of varlist *_3 {	// loop over provisions
	local var = substr( "`var_3'", 1, length("`var_3'")-2)	// remove suffix "_3"
	rename `var_3' `var'
}

* We remove firms not in the Ficus sample (why are there such firms?)
keep if sample_ficus==1

* Sampling rate
gen samplingrate = year0_sine<. if inlist(year0,2006,2010)
drop samplingrate

* We only keep firms in SINE 
drop if year0_sine == .

gen lage = log(agea)

label var educhigher 	"\addlinespace Education \\ \addlinespace \hspace{1.5em}College"
label var grandeeco 	"\hspace{1.5em}Elite college"
label var serial 		"Serial entrepreneur"
label var lage 			"Age"

* Restriction to SINE sample -> Missing are zeros 
local RHS "educhigher grandeeco lage serial"
foreach var of varlist `RHS' { 
	replace `var' = 0 if `var' == .
} 

*--------------
* REGRESSIONS
*--------------
	
	eststo clear
	foreach var in `RHS'{
		qui eststo: reghdfe any_deviation `var', a(year0) vce(cluster siren)
		$trueobs
	}
	qui eststo: reghdfe any_deviation `RHS', a(year0) vce(cluster siren)
	$trueobs	
	
	estfe . est* , labels( ///
		year0	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Year of creation")
	return list	

	esttab using "$result/bylaws_sine.tex", ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))
}

*-------------------------------------------------------------------------------
* Table 5: Top/Bottom Industries by Exposure to the Reform
*-------------------------------------------------------------------------------
{

*** Bring English translation of French industry names 
	import excel using "$source_publ/naf5_English_translation",case(lower) first clear 
	keep naf5 english_translation
	tempfile english_translation 
	save `english_translation'
	
	
	use ${exposure} naf5 ///
		using "$output/new_inc_workingsample_th0", clear
	bys naf5: keep if _n==1
		
	merge 1:1 naf5 using "$source_publ/nomenclature_fr_naf5", nogen keep(3)
	gen label_fr_treated = upper(substr(label_fr, 1, 1)) + lower(substr(label_fr, 2, .))

	gen minus_${exposure} = - ${exposure}

	sort ${exposure}
	gen rank = _n

	sort minus_${exposure}
	gen minus_rank = _n

	keep if rank <= 10 | minus_rank <= 10
	replace ${exposure} = round(${exposure},.1)
	tostring ${exposure}, replace format(%9.1f) force 
	
	merge 1:1 naf5 using `english_translation',nogen 
	
	export excel "$result/top_bottom_exposure.xls", replace
		
	preserve
		keep if minus_rank <= 10	
		gsort -${exposure}
		file open texout using "$result/top_exposure.tex", write replace
		file write texout "Code & Sector & Average Equity/Assets \\\\" _n
		file write texout "\midrule" _n

		quietly {
			forvalues i = 1/`=_N' {
				local naf = naf5[`i']
				local label = english_translation[`i']
				local value = ${exposure}[`i']
				file write texout "`naf' & `label' & `value' \\" _n
			}
		}

		file write texout "\bottomrule" _n
		file close texout

	restore 	


	preserve
		keep if rank <= 10	
		gsort -${exposure}
		file open texout using "$result/bottom_exposure.tex", write replace
		file write texout "Code & Sector  & Average Equity/Assets \\" _n
		file write texout "\midrule" _n

		quietly {
			forvalues i = 1/`=_N' {
				local naf = naf5[`i']
				local label = english_translation[`i']
				local value = ${exposure}[`i']
				file write texout "`naf' & `label' & `value' \\" _n
			}
		}

		file write texout "\bottomrule" _n
		file close texout

	restore 	
}


*===============================================================================
*===============================================================================
* Regression Tables 
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Table 6: Effect of the Reform on Flexible Form Adoption
*-------------------------------------------------------------------------------
{
	 	
	use $fe_reg_list $cluster siren year Z_post ///
		sample sas_var0 ///
		using "$output/new_inc_workingsample_th0", clear

	** Run regressions and produce table
	eststo clear
	run_did, lhs(sas_var0) rhs(Z_post) filename(Takeup_new)
}

*-------------------------------------------------------------------------------
* Table 7: Effect of the Reform on Tailored Bylaws
*-------------------------------------------------------------------------------
{

*** List of bylaw features
	use siren naf5 naf2 dep ze2010 year0_ficus sample_provisions* sample_shareholders* ///	
		any_dev* buyorsell_3 drag_3 ms_*_3 ///
		prio_issuance_3 preemp_3 noncomp_3 tag_3 lockup_3 free_3 ///	
		exclusion_3 dg_3 suspension_3 ad_nutum_3 governance_3 pref_*_3 ///		
		ad_nutum_3 dg_3 free_3 suspension_3 board_total_3 executive_total_3 ///
		using "$output/bylaws_firm_ficus", replace
	rename year0_ficus year 

	* Bring variables for regressions and keep only the matched sample 
	merge m:1 naf5 using "$output/characteristics_naf5_all",nogen keepusing($exposure ${SIZE} ${s_sasDEF}) keep(3)

	* Keep provisions in year 3, since they are cumulative over time (max by siren)
	* Keep if we observe the provisions at least once
	gen any_provisions = max(sample_provisions_0,sample_provisions_1, ///
	sample_provisions_2,sample_provisions_3) 
	gen any_shareholders = max(sample_shareholders_0,sample_shareholders_1, ///
	sample_shareholders_2,sample_shareholders_3) 

*** Clauses 	
	* Any deviation
	label var any_deviation_3 "Tailored bylaws"

	* Ownership
	gen pref_ownership_3 = max(ms_transfer_approval_3,ms_preemp_3,ms_exclusion_3)
	gen other_ownership_3 = max(buyorsell_3,drag_3) 
	gen any_ownership_3 = max(pref_ownership_3,other_ownership_3,prio_issuance_3,preemp_3,noncomp_3,tag_3,lockup_3,free_3) 
	lab var any_ownership_3  "Tailored ownership rights"

	* Governance
	gen any_governance_3 = max(exclusion_3,dg_3,suspension_3,ad_nutum_3,governance_3,pref_control_3)
	lab var any_governance_3 "\quad Tailored control rights"

	* Cash flow rights
	lab var pref_cf_any_3 "\quad Tailored cash-flow rights"
	
	* SAS specific clause
	gen any_sas_specific_3 = max(ad_nutum_3,dg_3,free_3,suspension_3, ///
	board_total_3,executive_total_3)	

*** Size and share sas
	gen size 		= ${SIZE}
	gen s_sas 		= ${s_sasDEF}
	gegen naf2year	= group(naf2 year)
	gegen geoyear	= group(${geo} year)
	
*** Regression 
	* Exposure to the reform	
	local Z $exposure 
	qui su `Z'   
	gen Z_post 		= `Z' / r(sd) * (year>2008)
	label var Z_post	 "\addlinespace Exposure\(\times\)Post"		
	
	eststo clear
    foreach var of varlist any_sas_specific_3 any_ownership_3 any_governance_3 ///
	pref_cf_any_3  { 
		
         eststo: reghdfe `var' Z_post if any_provisions & !missing(any_deviation_3), ///
			a(${fe_spec$fe_nspec$}) cluster($cluster) nocons
			$trueobs
    }  
    
    quietly $listFE
    esttab using "$result/reform_effect_bylaws.tex", ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))		
}	

*-------------------------------------------------------------------------------
* Table 8: Effect of the Reform on Firm Creation
*-------------------------------------------------------------------------------
{
	
*** Number of new firms by sector-year
	use sample sas naf2 naf5 year ///
		using "$output/new_inc_workingsample_th0" if sample =="new", clear
	gen new 	= 1
	gen newsas	= sas==1
	gen newsarl	= sas==0
	gcollapse (sum) new newsas newsarl , by(naf2 naf5 year)
	tempfile newfirm
	save `newfirm'

		
	* NB: the sample is not exactly balanced --> adjust for that 
	keep naf2 naf5
	bys naf5: keep if _n==1
	expand 9 
	bys naf5: gen year=2003+_n

	* merge back and assign zeros 
	merge 1:1 naf5 year using `newfirm',nogen 

	foreach var in new newsas newsarl {
		recode `var' . = 0 
// 		lhs `var' lhs_`var'
		egen `var'PRE 	= mean(cond(year<2008),`var',.)
		gen mpgr_`var' 	= (`var'-`var'PRE)/((`var'+`var'PRE)*.5)
	}	

*** Bring industry characteristics 
	merge m:1 naf5 using "$output/characteristics_naf5_all", nogen keep(1 3)	
	
*** Size and share sas
	gen size 		= ${SIZE}
	gen s_sas 		= ${s_sasDEF}
	
	
*** Reconstruct some variables
	* fixed effects
	gegen naf2year = group(naf2 year)
		
*** TABLE 
// 	capture drop newPRE
// 	rename entry_tot_m_naf5 newPRE
	
	gen un = 1
	
	* Exposure to the reform	
	cap drop Z*
	local Z $exposure 
	qui su `Z' 
	gen Z_post 		= `Z' / r(sd) * (year>2008)
	label var Z_post	 "\addlinespace Exposure\(\times\)Post"		
	
	local fe "naf5 naf2year"	
	local X = "c.s_sas#i.year"
	
	eststo clear 	
	foreach WEIGHT in un new {
		
		eststo: reghdfe mpgr_new Z_post [aw=`WEIGHT'] , a(`fe') cluster( $cluster )
		$trueobs
	
		eststo: reghdfe mpgr_new Z_post [aw=`WEIGHT'] , a(`X' `fe') cluster( $cluster )
		$trueobs
			
	}

	* table
	quiet $listFE	
	esttab using 	"$result/nb_newFirm.tex", drop(_cons) ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels($\checkmark$ --- )) 
}

*-------------------------------------------------------------------------------
* Table 9: Effect of the Reform on Capital
*-------------------------------------------------------------------------------
{		
	use $fe_reg_list $cluster Z_post ${K3clean}  ///
		using "$output/new_inc_workingsample_th0" , clear
		
	** Run regressions and produce table 
	eststo clear 
	run_did, lhs(${K3clean}) rhs(Z_post) filename(K_new)
	
	** Save coefficients in thousands of euro for last column 
	eststo: reghdfe ${K3clean} Z_post, a(${fe_spec$fe_nspec$}) cluster($cluster )
	number_exporting round(_b[Z_post],.01)*1000, name("$coeff/K_t3") digits(0)
	* effect relative to the mean 
	qui sum ${K3clean} if year <2008
	number_exporting round(_b[Z_post],.01)/r(mean), name("$coeff/K_t3_pct") digits(1) percent
	
}

*-------------------------------------------------------------------------------
* Table 10: Quantiles
*-------------------------------------------------------------------------------
{
	use $fe_reg_list $cluster Ktot3_e Ktot3${clean} Z_post ///
		using "$output/new_inc_workingsample_th0", clear
	
	gen Un 		= 1 
	gen Prepost = year>2008
	gen Year 	= year 
	gen All 	= 1 
	
*** Alternative measure of success: thresholds 	
	foreach var in Ktot3_e_5it { 
		
		foreach grtime in Un { 
			foreach grind in All {
			
				gegen group = group(`grtime' `grind') 
			
				eststo clear
				
				foreach PTILE in  20 40 60 80 { //  
					cap drop p`PTILE' 
					cap drop LHS
					gegen p`PTILE' 		= pctile(`var'), p(`PTILE') by(group)
					gen LHS				= `var' > p`PTILE' if `var' <.
					
					eststo: reghdfe LHS Z_post, a($fe_spec3) cluster($cluster ) nocons
					$trueobs	
				}
				
				quiet $listFE	
				esttab using 	"$result/robust_atlperf20_`var'_time`grtime'_ind`grind'.tex", ///
					$tableEnvironment ///
					indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))
				
			}	
		}
	}

}

*-------------------------------------------------------------------------------
* Table 11: Effect of the Reform on Startup Equity
*-------------------------------------------------------------------------------
{	

	use $fe_reg_list $cluster siren year Z_post  ///
		equity1 eqall1 ///
		${Eclean} eqall1${clean} ${K3clean} Ktot1${clean} ///
		using "$output/new_inc_workingsample_th0", clear
		
	** Run regressions and produce table 
	eststo clear	
		run_did, lhs(${Eclean}) rhs(Z_post) filename(Equity_new)
	
	* save coefficients in thousands of euro for last column 
	reghdfe ${Eclean} Z_post, a(${fe_spec$fe_nspec$}) cluster($cluster )
	number_exporting round(_b[Z_post],.01)*1000, name("$coeff/e_t1") digits(0)
				
*** Elasticity K / E 
	reghdfe ${Eclean} Z_post, a(${fe_spec$fe_nspec$}) cluster($cluster )
	gen e =  round(_b[Z_post],.01)*1000
	reghdfe ${K3clean} Z_post, a(${fe_spec$fe_nspec$}) cluster($cluster )
	gen K =round(_b[Z_post],.01)*1000
	number_exporting (K/e), name("$coeff/K_e_ela") digits(1)
	
	* Initial ratio 
	gen Ke = ${K3clean}/${Eclean}
	winsor4 Ke,outlier(tail) level(5) method(winsor)	
	quiet sum Ke if year<2008  
	number_exporting r(mean), name("$coeff/K3_e_pre") digits(1)

	* t+1/t+1
	cap drop Ke 
	gen Ke = Ktot1${clean}/${Eclean}
	winsor4 Ke,outlier(tail) level(5) method(winsor)	
	quiet sum Ke if year<2008  
	number_exporting r(mean), name("$coeff/K1_e_pre") digits(1)
	
*** Initial ratio for *total* equity 
	cap drop Ke 
	gen Ke = ${K3clean}/eqall1${clean}
	winsor4 Ke,outlier(tail) level(5) method(winsor)	
	quiet sum Ke if year<2008  
	number_exporting r(mean), name("$coeff/K3_tote_pre") digits(1)
	
	* t+1/t+1
	cap drop Ke 
	gen Ke = Ktot1${clean}/eqall1${clean}
	winsor4 Ke,outlier(tail) level(5) method(winsor) positive	
	quiet sum Ke if year<2008  
	number_exporting r(mean), name("$coeff/K1_tote_pre") digits(1)
	
*** Ratio retained earnings in total equity 
	gen re_tote = 1-(equity1/eqall1)
	quiet sum re_tote if year<2008  
	number_exporting r(mean), name("$coeff/s_re_tote") digits(1) percent
		
*** Ratio for incumbents 
	use Ke Keqall year using "$output/incumbents_workingSample",replace	
	quiet sum Ke if year<2008  
	number_exporting r(mean), name("$coeff/K1_e_pre_inc") digits(1)
	quiet sum Keqall if year<2008  
	number_exporting r(mean), name("$coeff/K1_tote_pre_inc") digits(1)
		
}

*-------------------------------------------------------------------------------
* Table 12: Dynamics and Survival
*-------------------------------------------------------------------------------	
{	
	
	use $fe_reg_list $cluster siren year Z_post ///
		sample Ktot*${clean} Y*_e  ///
		using "$output/new_inc_workingsample_th0", clear

*** Dynamics 	
	eststo clear 
	foreach t in 1 2 3 4 5  { //   
		local Y "Ktot`t'${clean}"
		* regression 
		eststo: reghdfe `Y' Z_post if Ktot3${clean} != . , ///
			a(${fe_spec$fe_nspec$}) cluster($cluster) nocons
			$trueobs
		* save coefficients in thousands of euro
		number_exporting round(_b[Z_post],.1)*1000, name("$coeff/K_t`t'") digits(0)
	} 
					
	quiet $listFE	
	esttab using "$result/Decomposition_K.tex" ///
	,  $tableClean_2 ///
	indicate( `r(indicate_fe)', labels(\(\checkmark\) --- )) 		

	
*** Survival
	eststo clear
	foreach t in 2 3 4 5 {  
	
		gen survival`t' = Y`t'_e > 0 & Y`t'_e <.		
	
		eststo: reghdfe survival`t' Z_post, a(${fe_spec$fe_nspec$})  cluster($cluster) nocons
		$trueobs
		
	}  
				
	quiet $listFE	
	esttab using "$result/Decomposition_K_extensive.tex" ///
		,  $tableClean_2 ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- )) 	
		
	** Unconditional proba of survival 
	quiet sum survival3
	number_exporting r(mean), name("$coeff/proba_survival_t3") percent digits(0)
		
}

*-------------------------------------------------------------------------------
* Table 13: Effect of the Reform on Labor and Revenues	
*-------------------------------------------------------------------------------
{	
	use $fe_reg_list $cluster L3${clean} Y3${clean} Z_post ///
		using "$output/new_inc_workingsample_th0" , clear
		
	** Run regressions and produce table 	
	eststo clear
	foreach var in L3 Y3 {
		run_did, lhs(`var'${clean}) rhs(Z_post) filename(LY_new)
	}
	
	** Output coefficient 
	foreach var in L3 Y3 {
		eststo: reghdfe `var'${clean} Z_post, a(${fe_spec$fe_nspec$}) cluster($cluster )
		local beta = _b[Z_post]
		number_exporting round(`beta',.01)*1000, name("$coeff/`var'") digits(0)
		* Change relative to the pre reform mean 
		qui sum `var' if year <2008
		number_exporting round(`beta',.01)/`r(mean)', name("$coeff/`var'_pct_change") digits(1) percent	
	}

}

*-------------------------------------------------------------------------------
* Table 14: Placebo Test: Incumbent Firms	
*-------------------------------------------------------------------------------
{		

	use "$output/incumbents_workingSample", clear
	
	** Run regressions and produce table 	
	eststo clear	
	run_did, lhs(g0_Ktot3_5it) rhs(Z_post) filename(K_inc)
}

