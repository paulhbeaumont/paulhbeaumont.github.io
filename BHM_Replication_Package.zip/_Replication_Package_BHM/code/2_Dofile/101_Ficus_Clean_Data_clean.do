
*===============================================================================
* Clean FICUS - FARE
*===============================================================================
{

*** Append data and bring clean geography variables
	* nb: restrict to the period up to 2013 since we do not go further
	clear
	local fyear ${fyear_all}
	local lyear ${lyear_all}
	
	forval yr =`fyear'/`lyear'{
		display in red "`yr'"
		append using "$temp/ficus_fare_nofilter_`yr'"
	}
	
	** DEAL WITH THE 2008 PB 
	* Linear interpolation when possible
	sort siren year
	local vars_interp "equity at debt avance_supplier credit_supplier avance_customer credit_customer autcapi"
	foreach var of local vars_interp {
		* Linear interpolation (firm present in 2007 and 2009)
		by siren: replace `var' = (`var'[_n+1]+`var'[_n-1])/2 if year==2008 & `var'==. 
		* Forward fill from 2009 (firm first appears in 2008)
		by siren: replace `var' = `var'[_n+1] if year==2008 & `var'==. 
		* Backward fill from 2007 (firm last appears in 2008)
		by siren:  replace `var' = `var'[_n-1] if year==2008 & `var'==. 
	}
	
*** Bring time consistent industry code and commune code 
	drop ape 
	merge 1:1 siren year using "$output/siren_naf2rev2_invariant_${fyear_all}_${lyear_all}",nogen keep(1 3) keepusing(naf5)
	drop if naf5 == "" // there is nothing we can do for these guys 
	
	 forvalues x=2(1)4{
		display in red "naf`x'"
		qui gen naf`x'	= substr(naf5,1,`x')
		qui destring naf`x',replace force
	}		
	
*** Geography 	
	drop dep commune
	merge 1:1 siren year using "$output/siren_commune_invariant_${fyear_all}_${lyear_all}",nogen keep(1 3)
		
	gen dep = floor(commune/1000)
	drop if dep == . // there is nothing we can for these guys 

*** First year in ficus-fare 
	merge m:1 siren using "$temp/ficus_fare_fyear",nogen keep(1 3)
	
	
*** Some basic filters to speed up the process (they always remove ALL the obs associated with one siren)		
	** Remove DOM-TOM 
	drop if dep >95
	
	** Fix the legal status at entry for all firms (important when we want to restrict to SARL or SAS)
	* Preserve the time varying version of cj
	gen cj_var = cj
	* Create  the time invariant version at entry
	gsort siren year 
	by siren: replace cj = cj[_n-1] if _n>1 
	
	label var cj 		"Legal status at entry"
	label var cj_var 	"Legal status: time varying"
	
	** Filter commercial legal status
	keep if substr(cj,1,1) == "5"
	destring cj cj_var,replace 
	
	* Keep manufacturing and services, exclude finance/utilities/waste
	keep if inrange(naf2, 10, 82) & !inrange(naf2, 35, 39) & !inrange(naf2, 64, 68)
  
   	* Drop holding companies
	drop if naf3==701
	
	/*
		Remove various industries + industries that appear late or disappear before end of sample 
	*/	
	* Check no change in the set of industries during the sample period
	gegen first_time 	= min(year),by(naf5)
	gegen last_time 	= max(year),by(naf5)	
	
	*<0.01% of observations with a new industry appearing or disappearing during the sample period
	tab first_time
	tab last_time
	sum year 
	drop if first_time > r(min) | last_time < r(max)
	drop first_time last_time
	
	* Add LIFI
	merge 1:1 siren year using "$temp/lifi" ,keep(1 3)
	gen subsidiary = _merge == 3
	drop _merge
	
*-------------------------------------------------------------------------------
* Filters based on accounting data
*-------------------------------------------------------------------------------	
 
	** Restrict on revenues positive and non missing
	qui keep if (ca >0  & ca <.) 
	
	** Drop zero asset or missing asset 
	qui keep if (at >0  & at <.) 

*-------------------------------------------------------------------------------
* Generate extra variables
*-------------------------------------------------------------------------------	


*** Replace negative values and missing values with zeros
	* This is intentional. Ficus-Fare rarely report zeros and instead 
	* assign missing 
	rename wages wagenet 
	foreach var in emp ca va at immoinc immocor equity div wagenet charsoc /*
	*/ credit_supplier ocli ni subvinv autcapi debt {
		replace `var' = 0 if `var' < 0 | `var' == .
	}
	
	** Identify SARL and SAS
	gen sas		= floor(cj/100)==57

	* compute total labor cost 
	gen wagegross = wagenet+charsoc

	* Total capital (tangible + intangible)
	gen immotot 			= immocor+immoinc

	gen eqall				= equity+autcapi
		
*** Some ratios used later 
	gen debt_at				= debt/at 
	gen ni_at				= ni/at 
	gen div_at				= div/at 

*** Net trade credit 
	gen totcredit_supplier	= credit_supplier+avance_supplier
	gen totcredit_customer	= credit_customer+avance_customer
	gen net_trade_credit 	= (totcredit_supplier-totcredit_customer)/ca 
	winsor4 net_trade_credit ,method(winsor) outlier(tail) level(1)

	* Employment
	rename emp eff 
	
	rename immotot Ktot 
	rename wagegross L 
	rename ca Y 
	
	save "$temp/ficus_fare_01",replace 
}

*===============================================================================
*===============================================================================
* Handle inconsistency in timing of creation date in ficus-fare
*===============================================================================
*===============================================================================

/*
	Produce multiple versions of age 
*/

{
*-------------------------------------------------------------------------------
* Version 1: first year in ficus-fare
*-------------------------------------------------------------------------------	

	use "$temp/ficus_fare_01",replace 
	gen age			= year-fyear_ff			

	keep cj_var sas siren year naf* dep commune age ///
		eff equity eqall *at ///
		Y Ktot L va ///
		subsidiary net_trade_credit totcredit_customer
		
	save "$temp/ficus_fare_01ageff",replace 
	
*** Save share of retained earnings in total equity 
	gen re_tote = 1-(equity/eqall)
	quiet sum re_tote if year<2008  
	number_exporting r(mean), name("$coeff/s_re_tote") digits(0) percent
	

}
*
