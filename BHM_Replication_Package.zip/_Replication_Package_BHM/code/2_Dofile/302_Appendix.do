
*===============================================================================	
*===============================================================================
* Graphs
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Figure D.1: Evolution of Contractual Tailoring Around the Reform
*-------------------------------------------------------------------------------
{

*--------------
* Data
*--------------

/* Sample: 1 obs = 1 firm. 
	Use provisions defined as the max over all years, i.e., the cumulative features in year 3
*/

use "$output/bylaws_firm_ficus", clear	// constructed in 134_Merge_Bylaws_Ficus.do

* Keep provisions in year 3, since they are cumulative over time (max by siren)
* Keep if we observe the provisions at least once
gen any_provisions = max(sample_provisions_0,sample_provisions_1, ///
sample_provisions_2,sample_provisions_3)
keep if any_provisions==1
drop *_0 *_1 *_2
foreach var_3 of varlist *_3 {	// loop over provisions
	local var = substr( "`var_3'", 1, length("`var_3'")-2)	// remove suffix "_3"
	rename `var_3' `var'
}

* We remove firms not Ficus-Fare 
keep if sample_ficus==1
merge 1:1 siren using "$output/dummy_sas", keep(1 3) keepusing(eversas) nogen 

*** Label the different provisions
	* Any deviation
	eststo clear
	label var any_deviation "Tailored bylaws"

	* Ownership
	gen pref_ownership = max(ms_transfer_approval,ms_preemp,ms_exclusion)
	gen any_ownership = max(prio_issuance,free,preemp,noncomp,exclusion,lockup,tag,drag,tagdrag,pref_ownership)

	lab var any_ownership  "\addlinespace\quad Tailored ownership rights"
	lab var prio_issuance  "\quad\quad Priority in share issuance"
	lab var preemp "\quad\quad Priority in share transfer"
	lab var free "\quad\quad Unrestricted share transfers"
	lab var noncomp "\quad\quad Non-compete"
	lab var exclusion "\quad\quad Shareholder exclusion"
	lab var pref_ownership "\quad\quad Class-specific ownership rights"
	lab var lockup "\quad\quad Lock-up period"
	lab var tag "\quad\quad Tag-along"
	lab var drag "\quad\quad Drag-along"

	* Governance
	gen any_governance = max(dg,suspension,ad_nutum,governance,pref_control)

	lab var any_governance "\addlinespace\quad Tailored control rights"
	lab var governance "\quad\quad Governance body"
	lab var dg "\quad\quad CEO can appoint executive officers"
	lab var suspension "\quad\quad Suspension of voting rights"
	lab var ad_nutum "\quad\quad Ad nutum CEO termination"
	lab var pref_control "\quad\quad Class-specific control rights"

	* Cash flow rights
	lab var pref_cf_any "\addlinespace\quad Tailored cash-flow rights"
	lab var warrant "\quad\quad Stock options"
	lab var ms_liq "\quad\quad Preferred liquidation rights"
	lab var ms_div "\quad\quad Preferred dividend rights"
	lab var ms_cashout "\quad\quad Class-specific cash-out rights"

	* VC backed
	replace vc = vc_siren==1 | vc_cb==1
	lab var vc "\addlinespace VC backed"

*** x100 to display stats in %
	foreach x of varlist any_deviation ///
		any_ownership prio_issuance preemp free noncomp exclusion lockup tag drag pref_ownership ///
		any_governance dg suspension ad_nutum governance pref_control ///
		pref_cf_any warrant ms_liq ms_div ms_cashout eversas vc {
		replace `x' = `x'*100
	}

*--------------
* Time-series figures
*--------------

* SAS-specific provisions
gen any_sas_specific = max(ad_nutum,dg,free,suspension,board_total,executive_total)

gen sas = eversas

* collapse by year and rescale %
local varlist any_deviation any_ownership any_governance pref_cf_any any_sas_specific sas
collapse (mean) `varlist', by(year0_ficus)
foreach var in `varlist' {
	replace `var' = `var'/100
}
lab var sas "Flexible bylaws legal form"
lab var any_sas_specific "Flexible bylaws-specific provisions"
lab var any_deviation "Tailored bylaws"
lab var any_ownership "Tailored ownership rights"
lab var any_governance "Tailored control rights"
lab var pref_cf_any "Tailored cash-flow rights"

* share of SAS using SAS-specific provisions
gen share_using_flex = any_sas_specific/sas // share of SAS using SS-specific provisions
l year0_ficus sas any_sas_specific share_using_flex any_ownership any_governance pref_cf_any
su sas any_sas_specific if year0_ficus<2008

*** Ownership
	twoway line ///
		any_ownership year0_ficus ///
		,   lcolor(maroon%90) lwidth(medthick)  ///
		ylabel(.2 "20%" 0.25 "25%" 0.3 "30%" 0.35 "35%",nogrid angle(0)) ///
		xtitle("") ytitle("") $graph_white
		graph export "$result/ownership_year.pdf", as(pdf) replace		
		graph close

*** Control
	twoway line ///
		any_governance year0_ficus ///
		,   lcolor(maroon%90) lwidth(medthick)  ///
		ylabel(0 "0%" 0.04 "4%" 0.08 "8%" 0.12 "12%",nogrid angle(0)) ///
		xtitle("") ytitle("") $graph_white
		graph export "$result/governance_year.pdf", as(pdf) replace	
		graph close

*** Cashflow rights
	twoway line ///
		pref_cf_any year0_ficus ///
		,   lcolor(maroon%90) lwidth(medthick)  ///
		ylabel(0.001 "0.1%" 0.002 "0.2%" 0.003 "0.3%" 0.004 "0.4%",nogrid angle(0)) ///
		xtitle("") ytitle("") $graph_white
		graph export "$result/pref_cf_year.pdf", as(pdf) replace
		graph close

}
*

*-------------------------------------------------------------------------------
* Figure D.2: Excluding industries one-by-one  
*-------------------------------------------------------------------------------
{
	
	use ${fe_reg_list} $cluster naf4 Z_post ${K3clean} ///
	using "$output/new_inc_workingsample_th0" , clear
	gen b	= . 
	gen se 	= . 
	gegen indID = group(naf4)
	qui sum indID 
	forval IND =`r(min)'/`r(max)'{
		di "`IND'/`r(max)'"
		qui reghdfe Ktot3_e_5it Z_post if indID !=`IND', a(${fe_spec3}) cluster($cluster) nocons
		qui replace b 	= _b[Z_post]	if _n==`IND'
		qui replace se 	= _se[Z_post]	if _n==`IND'
	}
	keep if b<. 
	keep b* se* 
	save "$temp/temp",replace
	
	use "$temp/temp",replace
	** Distribution of coefficients 
	twoway (hist b,fraction color(navy%30)) ///
	, xsize(8) $graph_white $leg_white ///
	ylabel(,nogrid) xtitle("Distribution of {&beta} coefficients") ytitle("")
 	graph export "$result/distribution_beta.pdf", as(pdf) replace		
	graph close
	
	** Distribution of t-stat
	gen tstat = abs(b/se)
	
	twoway (hist tstat,fraction color(navy%30)) ///
	, xsize(8) $graph_white $leg_white ///
	ylabel(,nogrid) xtitle("Distribution of t-stat") ytitle("")
 	graph export "$result/distribution_tstat.pdf", as(pdf) replace
	graph close

}
*

*-------------------------------------------------------------------------------
* Figure D.3: Effect of the Reform on Flexible Bylaws Adoption: New Firms vs Incumbents
*-------------------------------------------------------------------------------
{
	use $fe_reg_list $cluster sas_var0 sas_var1 $exposure  ///
		using "$output/incumbents_workingSample" , clear

	** Switch SAS for incumbents
	gen switch_sas = 1 if sas_var1 ==1 & sas_var0 == 0
	recode switch_sas . = 0 

	tempfile inc 
	save `inc'
	
	use $fe_reg_list $cluster sas_var0 $exposure  ///
		using "$output/new_inc_workingsample_th0",clear 
	gen sample = "new"
	append using `inc'
	replace sample = "inc" if sample == ""
	
*** Exposure to the reform	
	local Z $exposure 
	qui su `Z'   if sample == "new"
	gen Z 		= `Z' / r(sd) 
	
*** Estimate event study 	

	** New firms 
	preserve 
		keep if sample == "new"
		evstudydd sas_var0 year,treated(Z) shocktime(2007) period(2 4) ///
			fe(${fe_spec$fe_nspec$}) cl($cluster) name("$gcoeff/takeup_new")
	restore 
	
	** Incumbent firms 
	preserve 
		keep if sample == "inc"
		evstudydd switch_sas year,treated(Z) shocktime(2007) period(2 4) ///
		fe(${fe_spec$fe_nspec$}) cl($cluster)  name("$gcoeff/takeup_inc")
	restore 
	
	
*** Output figure 
	clear
	local i = 0 
	foreach sample in new inc  {
		local i = `i'+1
		append using "$gcoeff/takeup_`sample'"	
		Coeffyear `i' 2007
	}
	
	graph twoway ///
	(rcap B1inf B1sup t1, $se $light_red) ///
	(scatter B1 t1, $beta_diamond $redF) ///		
	(rcap B2inf B2sup t2, $se $light_blue) ///
	(scatter B2 t2, $beta_round $blueF) ///				
	$graph ylabel(,nogrid angle(0)) ///
	$graph_white $leg_white  xsize(8) leg(cols(2) pos(6) ) ///
	leg(order (2 "New firms" 4 "Incumbents"))
	graph export "$result/takeup_new_inc.pdf", as(pdf) replace
	graph close
	
}

*===============================================================================	
*===============================================================================
* Regressions Tables
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Table D.1: Effect of the Reform on Capital: Excluding Distribution Sector
*-------------------------------------------------------------------------------
{
	use naf2 $fe_reg_list $cluster Z_post ${K3clean}  ///
		using "$output/new_inc_workingsample_th0" , clear

	** Drop retail 
	drop if inlist(naf2,46,47)
	
	** Run regressions and produce table 
	eststo clear 
	run_did, lhs(${K3clean}) rhs(Z_post) filename(robust_supermarket_K)
	
}
*

*-------------------------------------------------------------------------------
* Table D.2: Effect of the Reform on Capital: Controlling for Trade Credit
*-------------------------------------------------------------------------------
{	
	use $fe_reg_list $cluster Z_post ${K3clean} net_trade_credit* ///	
	using "$output/new_inc_workingsample_th0" , clear
	
	rename net_trade_credit3_e net_trade_credit

	** Net trade credit pre-reform
	egen m_net_trade_credit = mean(cond(year<2008),net_trade_credit,.),by(naf5)
			
	** Define new control 
	local X "i.year#c.net_trade_credit"
	
	** Run regressions and output table 
	eststo clear 
	forvalues i = 1/$fe_nspec {
		eststo: reghdfe ${K3clean} Z_post, a(${fe_spec`i'} `X') cluster($cluster) nocons
		$trueobs
	}
    quiet $listFE
    esttab using "$result/robust_tradeCredit_K.tex", ///
        $tableEnvironment ///
        indicate(`r(indicate_fe)', labels($\checkmark$ ---))

}
*

*-------------------------------------------------------------------------------
* Table D.3: Effect of the Reform on Capital: Controlling for HHI
*-------------------------------------------------------------------------------
{
	use $fe_reg_list $cluster Z_post naf3 ${K3clean} ///
	using "$output/new_inc_workingsample_th0" , clear

*** Bring industry hhi  		
	merge m:1 naf3 using "$output/hhi_up_down_focal",nogen keep(3)
	
*** Define new control 
	local X "i.year#c.hhi_downstream i.year#c.hhi_upstream i.year#c.hhi"
	
*** Run regressions and output table 
	eststo clear 
	forvalues i = 1/$fe_nspec {
		eststo: reghdfe ${K3clean} Z_post, a(${fe_spec`i'} `X') cluster($cluster) nocons
		$trueobs
	}
    quiet $listFE
    esttab using "$result/robust_hhi_K.tex", ///
        $tableEnvironment ///
        indicate(`r(indicate_fe)', labels($\checkmark$ ---))
	
}
*

*-------------------------------------------------------------------------------
* Table D.4: Effect of the Reform on Capital: Controlling for Share auto-entrepreneurs 
*-------------------------------------------------------------------------------
{
	use $fe_reg_list $cluster Z_post ${K3clean} ///
	using "$output/new_inc_workingsample_th0" , clear
		
	merge m:1 naf5 using "$output/share_auto_entrepreneurs2009",nogen keep(1 3)
	recode auto . = 0 

*** Define new control 
	local X "i.year#c.auto"
	
*** Run regressions and output table 
	eststo clear 
	forvalues i = 1/$fe_nspec {
		eststo: reghdfe ${K3clean} Z_post, a(${fe_spec`i'} `X') cluster($cluster) nocons
		$trueobs
	}
    quiet $listFE
    esttab using "$result/robust_autoEntrepreneur_K.tex", ///
        $tableEnvironment ///
        indicate(`r(indicate_fe)', labels($\checkmark$ ---))

}
*

*-------------------------------------------------------------------------------
* Table D.5: Alternative Definition of Exposure
*-------------------------------------------------------------------------------
{	
	global exposure_alt Meq_at_p03a04 Meq_at_p03aAll medeq_at_p03a04 medeq_at_p03aAll

	use $fe_reg_list $cluster naf4 naf5 Ktot3_e*  ///
		using "$output/new_inc_workingsample_th0" , clear
		
	* Exposure constructed at naf5 level
	merge m:1 naf5 using "$temp/exposureReform_naf5", nogen keep(1 3) keepusing($exposure_alt)
	foreach x of varlist $exposure_alt {
		rename `x' `x'_naf5
	}
	
	* Exposure constructed at naf4 level
	merge m:1 naf4 using "$temp/exposureReform_naf4", nogen keep(1 3) keepusing($exposure_alt)
	foreach x of varlist $exposure_alt {
		rename `x' `x'_naf4
	}			
	
	
*** Run regression 
	eststo clear
	
	foreach Z in $exposure_alt { //
		foreach group in naf4 naf5{
	
			capture drop Z_post
			qui su `Z'_`group'  
			gen Z_post 		= `Z'_`group' / r(sd) * (year>2008)
			label var Z_post	 "\addlinespace Exposure\(\times\)Post"		
			
			eststo: reghdfe Ktot3_e_5it Z_post , a(${fe_spec$fe_nspec$}) cluster($cluster) nocons
			$trueobs
		}

	} 
	
	quiet $listFE	
	esttab using 	"$result/robust_altexposure.tex", ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))
}
*

*-------------------------------------------------------------------------------
* Table D.6: Alternative Definition of Exposure (Total Equity)
*-------------------------------------------------------------------------------
{
	
	global exposure_alt Meqall_at_p03a04 Meqall_at_p03aAll medeqall_at_p03a04 medeqall_at_p03aAll

	use $fe_reg_list $cluster naf4  Ktot3_e*  ///
		using "$output/new_inc_workingsample_th0" , clear

	merge m:1 naf5 using "$temp/exposureReform_naf5_eqall", nogen keep(1 3) keepusing($exposure_alt)		
	foreach x of varlist $exposure_alt {
		rename `x' `x'_naf5
	}
	
	merge m:1 naf4 using "$temp/exposureReform_naf4_eqall", nogen keep(1 3) keepusing($exposure_alt)
	foreach x of varlist $exposure_alt {
		rename `x' `x'_naf4
	}	

	
*** Run regression 
	eststo clear
	
	foreach Z in $exposure_alt { //
		foreach group in naf4 naf5{
	
			capture drop Z_post
			qui su `Z'_`group'  
			gen Z_post 		= `Z'_`group' / r(sd) * (year>2008)
			label var Z_post	 "\addlinespace Exposure\(\times\)Post"		
			
			eststo: reghdfe Ktot3_e_5it Z_post , a(${fe_spec$fe_nspec$}) cluster($cluster) nocons
			$trueobs
		}

	} 
	
	quiet $listFE	
	esttab using 	"$result/robust_altexposure_eqall.tex", ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))
	
}
*

*-------------------------------------------------------------------------------
* Table D.7: Alternative Treatment of Outliers
*-------------------------------------------------------------------------------
{	
	use $fe_reg_list $cluster siren Z_post ///
		using "$output/new_inc_workingsample_th0" , clear
	
*** Bring alternative treatment of outliers 
	merge 1:1 siren year using "$output/outliersRobust_new",nogen 

	local var "Ktot3_e"
	eststo clear
	foreach meth in "_3it" "_3i" "_5it" "_5i" "_95t" "_95w" "_99t" "_99w" { // 			
			 
		eststo: reghdfe `var'`meth' Z_post , a(${fe_spec$fe_nspec$}) cluster($cluster) nocons
		$trueobs

	}  
	
	quiet $listFE	
	esttab using 	"$result/robust_outliers_K.tex", ///
		$tableEnvironment ///
		indicate( `r(indicate_fe)', labels(\(\checkmark\) --- ))
}
*
