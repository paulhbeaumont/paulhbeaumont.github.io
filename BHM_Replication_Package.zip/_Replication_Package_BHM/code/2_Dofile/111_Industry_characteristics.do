	
*===============================================================================
* Share auto-entrepreneurs 
*===============================================================================

	use "$temp/SIRENE_creation_2009",replace
	gen auto = auto_entrepreneur == "1"
	rename apen naf5 
	gcollapse(mean) auto ,by(naf5)
	save "$output/share_auto_entrepreneurs2009",replace 

*===============================================================================
* Exposure to the reform 
*===============================================================================
{
	use age siren year equity at sas naf5 naf4 ///
		using "$temp/ficus_fare_01ageff" if year<=2007, clear
		
	rename equity eq 
	
	* Share asset funded by equity 
	foreach num in eq{ 
		foreach denom in at{
			local X "`num'_`denom'"
			gen `X' = (`num'/`denom')*100	
			
			winsor4 `X',method(winsor) group(year) outlier(tail) level(1)
		}
	}
	
	* Use naf5 as well as naf4 because naf4 will be used for robustness
	foreach group in naf4 naf5{
		preserve 
		
			* Conditions
			gen period03 	= year<=2003 
			
			gen ageAll		= 1 
			gen age04		= age <= 4
			gen age01		= age <= 1
				
			foreach num in eq{ 
				local X "`num'_at"
				foreach age in All 04 01{ 
					gen M`X'_p03a`age'   = `X' if period03==1 & age`age'==1
					gen med`X'_p03a`age' = `X' if period03==1 & age`age'==1						
				}
			}
			* * Share SAS 
			foreach period in 03{
				foreach age in All 04 01{
					cap drop temp N Nsas 
					gen temp 						= period`period'==1& age`age'==1
					gegen N 						= sum(temp),by(`group')
					gegen Nsas 						= sum(temp*sas),by(`group')
					gen s_sas_p`period'a`age'		= Nsas/N
				}
			}
			
			gen entry_tot 	= age==0
			foreach period in 03{
				gen entry_tot_p`period'	= entry_tot if period`period'==1
			}
			* average number of new firms per year by sector
			gegen entry_tot_m = sum(entry_tot/(2012-2004+1)), by(`group')
			
			
			* collapse by sector
			gcollapse (mean) M* s_sas* entry_tot_m (median) med* (sum) entry_tot_p*, by(`group') 
			
			save "$temp/exposureReform_`group'",replace 
			
		restore
	}
	
}
*

*===============================================================================
* Exposure to the reform, robustness: total equity (share capital + retained earnings) 
*===============================================================================
{
	
	use age siren year eqall at sas naf5 naf4 ///
		using "$temp/ficus_fare_01ageff" if year<=2007, clear
		
	* Share asset funded by equity 
	foreach num in eqall { 
		foreach denom in at {
			local X "`num'_`denom'"
			gen `X' = (`num'/`denom')*100	
			
			winsor4 `X',method(winsor) group(year) outlier(tail) level(1)
		}
	}
	
	* Use naf5 as well as naf4 because naf4 will be used for robustness
	foreach group in naf4 naf5{
		preserve 
		
			* Conditions
			gen period03 	= year<=2003 
			gen ageAll		= 1 
			gen age04		= age <= 4
				
			foreach num in eqall { 
				local X "`num'_at"
				foreach age in All 04 { 
					gen M`X'_p03a`age'   = `X' if period03==1 & age`age'==1
					gen med`X'_p03a`age' = `X' if period03==1 & age`age'==1						
				}
			}
			* Share SAS 
			foreach period in 03{
				foreach age in All 04{
					cap drop temp N Nsas 
					gen temp 						= period`period'==1& age`age'==1
					gegen N 						= sum(temp),by(`group')
					gegen Nsas 						= sum(temp*sas),by(`group')
					gen s_sas_p`period'a`age'		= Nsas/N
				}
			}
			
			gen entry_tot 	= age==0
			foreach period in 03{
				gen entry_tot_p`period'	= entry_tot if period`period'==1
			}
			* average number of new firms per year by sector
			gegen entry_tot_m = sum(entry_tot/(2012-2004+1)), by(`group')
			
			
			* collapse by sector
			gcollapse (mean) M* s_sas* entry_tot_m (median) med* (sum) entry_tot_p*, by(`group') 
			
			save "$temp/exposureReform_`group'_eqall",replace 
			
		restore
	}
	
	
}
*

*===============================================================================
* Other industry characteristics  
*===============================================================================

{
	local SAMPLE ageff 
	local group "naf5"
	
	use naf5 siren year at age ///
		using "$temp/ficus_fare_01ageff" if year<=2003, clear
		
	* Conditions
	gen period03 	= year<=2003 
	
	gen ageAll		= 1 
	gen age04		= age <= 4
	gen age01		= age <= 1

	foreach X in at { 
		foreach period in 03{
			foreach age in All 04 01{
				gen M`X'_p`period'a`age'	=  `X' if period`period'==1& age`age'==1
				gen med`X'_p`period'a`age' 	=  `X' if period`period'==1& age`age'==1						
			}
		}
	}
	* collapse by sector
	gcollapse (mean) M* (median) med*, by(`group') 
	foreach var of varlist M*{
		gen log_`var' = log(`var')
	}		
	save "$temp/characteristicsPRE_naf5",replace 
	
}
*		

*===============================================================================
* Industry sale volatility
*===============================================================================	
{
	use naf5 siren year Y using "$temp/ficus_fare_01" if year<=2007, clear
	gegen firmid = group(siren)
	sort firmid year
	xtset firmid year 

	* Firm-level sales growth
	gen gY = (Y-L.Y)/(.5*(Y+L.Y)) if L.Y>=1 & Y>=1

	* Mean and S.D. at industry-year level
	gcollapse (mean) gindY=gY (sd) sd_gY=gY, by(naf5 year)

	* Industry S.D. of sales growth
	gcollapse (count) n_year=sd_gY (sd) sd_gindY=gindY (mean) sd_gY, by(naf5)

	lab var sd_gindY "Industry-level volatility of industry sales growth"
	lab var sd_gY "Industry-level volatility of firm sales growth"
	save "$output/indvolat_naf5", replace			
}
*			

*===============================================================================
* Upstream and downstream competition 
*===============================================================================
{
*** HHI pre reform period 
	use naf3 Y year using "$temp/ficus_fare_01" if year<=2007, clear
	gegen totY 	= sum(Y),by(naf3)
	gen s2		= (Y/totY)^2
	gcollapse(sum) hhi=s2,by(naf3 year)
	
	gcollapse(mean) hhi,by(naf3)
	save "$temp/hhi",replace 
	
*** HHI upstream
	use "${output}/io_2017", replace
	* sum over destinations ("to")
	gegen totvalue = sum(value),by(naf_to)
	gen s_upstream = value / totvalue 
	recode s_upstream . = 0 
	
	rename naf_from naf3 
	joinby naf3 using "$temp/hhi"
	
	gen hhi_upstream = hhi*s_upstream
	gcollapse(sum) hhi_upstream,by(naf3)
	save "$temp/hhi_upstream",replace 
	
*** HHI downstream
	use "${output}/io_2017", replace
	* sum over destinations ("to")
	gegen totvalue 			= sum(value),by(naf_from)
	gen s_downstream 		= value / totvalue 
	recode s_downstream . 	= 0 
	
	rename naf_to naf3 
	joinby naf3 using "$temp/hhi"
	
	gen hhi_downstream = hhi*s_downstream
	gcollapse(sum) hhi_downstream,by(naf3)
	save "$temp/hhi_downstream",replace 
			
*** Assemble all HHI 
	use "$temp/hhi_downstream",replace 
	merge 1:1 naf3 using "$temp/hhi_upstream",nogen 
	merge 1:1 naf3 using "$temp/hhi",nogen 
	save "$output/hhi_up_down_focal",replace
	
}
*	

