




*-------------------------------------------------------------------------------
* Extract list 5 digit naf2 rev1 and naf2-rev2
*-------------------------------------------------------------------------------

*** Naf rev1 
	import excel using "$source_publ/naf2003_liste_n5.xlsx",clear first case(lower)
	rename code naf2_rev1
	replace naf2_rev1 = subinstr(naf2_rev1,".","",.)
	keep naf2_rev1
	compress
	save "$temp/naf2003_liste_n5",replace 

*** Naf2 rev2 	
	import excel using "$source_publ/naf2008_5_niveaux.xls",clear first case(lower)
	keep niv5 
	rename niv5 naf2_rev2
	replace naf2_rev2 = subinstr(naf2_rev2,".","",.)
	compress
	save "$temp/naf2008_liste_n5",replace 
	
*===============================================================================	
*===============================================================================
* Time consistent industry
*===============================================================================
*===============================================================================
	
*===============================================================================
* Time consistent industry 
*===============================================================================
{	

*-------------------------------------------------------------------------------
* Clean Ficus and assign consistent naf2-rev1
*-------------------------------------------------------------------------------

*** FICUS  
	local fyear ${fyear_all}
	forval yr = `fyear'/2007{
		display in red "ficus `yr'"

		quiet{
			use catotal siren ape using "$source_conf/ficusfare/ficus_`yr'" , clear 
			gen year = `yr'	
			* make sure siren is 9 digit string + keep 1 obs per siren
			tostring siren,replace 
			replace siren  = substr("00000"+siren,-9,.)
			drop if siren==""|siren=="."|siren=="0"|siren=="000000000"	
			
			gsort siren catotal
			by siren: keep if _n==_N 	
			
			keep siren year ape 
			save "$temp/ficus_fare_`yr'",replace 
		}
	}
	*
	
*** Append ficus 	
	clear 
	local fyear ${fyear_all}
	forval yr = `fyear'/2007{
		append using "$temp/ficus_fare_`yr'"
	}	
	
*-------------------------------------------------------------------------------
* Convert all naf93 into naf2 rev1 (using inline crosswalk)
*-------------------------------------------------------------------------------
{	
	*** Create crosswalk inline
	preserve
		clear
		input str4 old_ape str4 new_ape
		"271Z" "271Y"
		"273J" "271Y"
		"282A" "282C"
		"282B" "282C"
		"287M" "287Q"
		"287P" "287Q"
		"321B" "321C"
		"291C" "291B"
		"292K" "292L"
		"295C" "295B"
		"295P" "295R"
		"401Z" "401A"
		"402Z" "402A"
		"516G" "518G"
		"516J" "518J"
		"516N" "518P"
		"516A" "518A"
		"516C" "518C"
		"516E" "518E"
		"516K" "518M"
		"516L" "518N"
		"517Z" "519A"
		"551D" "551A"
		"642A" "642C"
		"642B" "642C"
		"711Z" "711A"
		"722Z" "722A"
		"900B" "900G"
		"900C" "900E"
		"922C" "922E"
		"923D" "921D"
		"923H" "923K"
		"923J" "923K"
		"926C" "930L"
		"7421" "742A"
		"7422" "742A"
		"7424" "742B"
		"7425" "742C"
		"7426" "742B"
		"7431" "672Z"
		"7439" "703A"
		"8541" "851C"
		"8542" "851C"
		"8553" "851C"
		"8555" "851C"
		"8559" "851C"
		"8574" "851C"
		"8599" "851C"
		"7413" "741C"
		"7416" "741G"
		"7417" "741G"
		"7419" "741J"
		"7423" "748G"
		"7489" "748G"
		"7481" "748K"
		"8044" "804D"
		"9233" "923K"
		"9239" "745A"
		"9911" "672Z"
		"9915" "701A"
		"5908" "745A"
		"7714" "741G"
		"8121" "741G"
		"5910" "702C"
		"5909" "518P"
		"7801" "671E"
		"6506" "502Z"
		end
		tempfile crosswalk
		save `crosswalk'
	restore
	
	*** Apply crosswalk
	rename ape old_ape
	merge m:1 old_ape using `crosswalk', keep(1 3) nogen
	gen ape = cond(new_ape != "", new_ape, old_ape)
	drop old_ape new_ape
	
	*** Siren-specific fixes (edge cases requiring individual treatment)
	replace ape = "366E" if ape == "9239" & siren == "450797238"
	replace ape = "748K" if ape == "9916" & siren == "452990682"
	replace ape = "642D" if ape == "9916" & siren == "429146301"
	replace ape = "701A" if ape == "9990" & siren == "328070636"
	replace ape = "633Z" if ape == "9990" & siren == "399296979"
	replace ape = "524R" if ape == "9990" & (siren == "399296979" | siren == "444520035")
	replace ape = "741G" if ape == "9990" & siren == "442915559" 
	replace ape = "731Z" if ape == "9990" & siren == "484583364" 
	replace ape = "744A" if ape == "9990" & siren == "331068585" 
	replace ape = "804C" if ape == "9990" & siren == "410992903" 
	replace ape = "748K" if ape == "9990" & siren == "442944443" 
	replace ape = "722A" if ape == "9990" & siren == "447918277" 
	replace ape = "515C" if ape == "9990" & siren == "421506486" 
	replace ape = "633Z" if siren == "438328957"
	replace ape = "634A" if siren == "441585577"
	replace ape = "521C" if siren == "443151170"

	compress
	save "$temp/ficus_cleanedAPE_naf2Rev1",replace
	
}	
*
	
*-------------------------------------------------------------------------------
* Basic cleaning of ape (preserve time varying definition)
*-------------------------------------------------------------------------------
	
	use "$temp/ficus_cleanedAPE_naf2Rev1",replace
	
	gen flag_digit_last = regexm(substr(ape, -1, 1), "[0-9]")
	
	* Drop firms that have ALL observations missing industry 
	gen missing 	= (substr(ape,1,3)=="999"|ape=="000Z"|ape=="") | flag_digit_last==1
	gegen totmiss	= sum(missing),by(siren)
	gegen nbobs		= sum(1),by(siren)
	drop if totmiss/nbobs ==1
	drop nbobs 
	
	* Replace ape==9999|ape==000Z (missing) when another ape code is provided for this firm
	* Do the same for the few wrongly coded ape code that ends with a number (it is always a letter)
	* Only keep the problematic firms to speed up 
	preserve 
		keep if totmiss>=1
		sort siren year
		* Forward fill (make sure that we do not assign the backward value the year of the change)
		* Eg: in 2003, we have new codes, if it is missing, we do not want to use 2002 (old code)
		by siren: replace ape=ape[_n-1] if _n>1 & missing==1
		
		* Backward fill 
		gsort siren -year
		by siren: replace ape=ape[_n-1] if _n>1 & missing==1 
		replace ape="" if missing==1
		tempfile temp 
		save `temp'
	restore 
	* bring back the cleaned ape 
	drop if totmiss>=1
	append using `temp'
	drop totmiss 
	
	** fill in ape when ape is changing one year and going back to its initial value (a mistake)
	sort siren year 
	replace ape=ape[_n-1] if ape!=ape[_n-1] & siren==siren[_n-1] & ape!=ape[_n+1] & siren==siren[_n+1] & ape[_n-1]==ape[_n+1]

	drop missing
	compress
	save "$temp/ficus_cleaned_naf2rev1",replace 	
	
	
*===============================================================================
* Clean Fare 
*===============================================================================
{
*-------------------------------------------------------------------------------
* Assemble fare 
*-------------------------------------------------------------------------------
{	
	local lyear ${lyear_all}
	forval yr = 2008/`lyear'{
		if `yr' == 2008{
			use siren* catotal* ape* ///
				using "$source_conf/ficusfare/fare_`yr'", clear 
			rename(siren_08 catotal_08 ape_08) ///
			(siren catotal ape)
		}
		if `yr'>=2009{
			use siren redi_r401 redi_r402 redi_r403 ape_diff ///
				using "$source_conf/ficusfare/fare_`yr'", clear 
			
			gegen catotal = rowtotal(redi_r401 redi_r402 redi_r403)
			cap rename ape_diff ape
		}
		* Ensure siren is 9 digit and add leading zeros when not
		drop if siren==""|siren=="."|siren=="0"|siren=="000000000"	
		replace siren = substr("00000000"+siren,-9,.)

		* keep 1 obs per siren
		gsort siren catotal
		by siren: keep if _n==_N
		gen year = `yr'
		keep siren year ape
		compress
		save "$temp/ficus_fare_`yr'",replace 

	}
	
*** Append 
	clear 
	local lyear ${lyear_all}
	forval yr = 2008/`lyear'{
		append using "$temp/ficus_fare_`yr'"
	}
	
	** some ape codes are wrong 
	* in general it is just one obs for one siren
	* using the info on societe.com we assign the correct code 
	
	replace ape = "4321A" if ape == "4321Z"
	replace ape = "4617A" if ape == "4671A"
	replace ape = "6820A" if ape == "4711Z"	
	replace ape = "4791A" if ape == "4771B"
	replace ape = "6420Z" if ape == "5610Z"
	compress
	save "$temp/fare",replace 
	
*** Check that all industries in fare have a naf2 rev2 code
	preserve 	
		use ape using "$temp/fare",replace
		gduplicates drop ape, force
		tempfile temp 
		save `temp'
		
		use "$temp/naf2008_liste_n5",replace 
		rename naf2_rev2 ape 
		merge 1:1 ape using `temp'
		* condition is: the unmerged should always be missing
		gen test = 1 if _merge==2 & ape !="" & ape!="0000Z"  
		assert test == . 
	restore		

}
*	
*-------------------------------------------------------------------------------
* Basic cleaning of ape (preserve time varying definition)
*-------------------------------------------------------------------------------
{	
/*
	Careful: we do our best to preserve the time-varying nature of the information 
	we only try to handle cells where the info is missing one year but present in other years 
*/

	use "$temp/fare",replace 

	* Identify last character to be a number (this is a mistake it should always be a letter)
	gen flag_digit_last = regexm(substr(ape, -1, 1), "[0-9]")
	
	* Drop firms that have ALL observations missing industry 
	gen missing 	= (substr(ape,1,3)=="999"|ape=="000Z"|ape=="") | flag_digit_last==1
	gegen totmiss	= sum(missing),by(siren)
	gegen nbobs		= sum(1),by(siren)
	drop if totmiss/nbobs ==1
	drop nbobs 
	
	preserve 
		keep if totmiss>=1
		sort siren year
		* Forward fill (make sure that we do not assign the backward value the year of the change)
		* Eg: in 2003, we have new codes, if it is missing, we do not want to use 2002 (old code)
		by siren: replace ape=ape[_n-1] if _n>1 & missing==1
		
		* Backward fill 
		gsort siren -year
		by siren: replace ape=ape[_n-1] if _n>1 & missing==1 
		replace ape="" if missing==1
		tempfile temp 
		save `temp'
	restore 
	* bring back the cleaned ape 
	drop if totmiss>=1
	append using `temp'
	drop totmiss missing

	sort siren year
	* fill in ape when ape is changing one year and going back to its initial value (a mistake)
	replace ape=ape[_n-1] if ape!=ape[_n-1] & siren==siren[_n-1] & ape!=ape[_n+1] & siren==siren[_n+1] & ape[_n-1]==ape[_n+1]

	compress
	save "$temp/fare_cleaned",replace 
}
*
}
*	
	
*===============================================================================
* Compute transition matrix naf2-rev1 --> naf2-rev2    
*===============================================================================
{		
	** Identify modal industry for firms that change industry 
	/* (do it manually to ensure consistent unique sorting)
		nb: do it separately before and after 08 to avoid problem due to industry code change 
	*/
	
	*** Assign one modal industry per firm in ficus 
	* (classification pre-2007 included) 
	use "$temp/ficus_cleaned_naf2rev1" ,replace 	
	gegen sort1 = sum(1) if ape!="",by(siren ape)
	gsort siren -sort1 ape // include ape as a sorting key to handle cases where the nb of times an industry appear has ties 
	
	by siren: gen ape_modal2002 = ape if _n==1
	by siren: replace ape_modal2002 = ape_modal2002[_n-1] if _n>1
	compress
	save "$temp/modal_pre2007", replace
	
*** Assign one modal industry per firm in fare (classification post-2007) 
	use "$temp/fare_cleaned",replace 	
	gegen sort1 = sum(1) if ape!="",by(siren ape)
	gsort siren -sort1 ape // include ape as a sorting key to handle cases where the nb of times an industry appear has ties 
	
	by siren: gen ape_modal2008 = ape if _n==1 
	by siren: replace ape_modal2008 = ape_modal2008[_n-1] if _n>1 
	drop sort1
	
*** Now append both 	
	append using "$temp/modal_pre2007"
	
	* make sure each firm that exists around 08 has one combination of ape defined
	gsort siren -ape_modal2002 
	by siren: replace ape_modal2002 = ape_modal2002[_n-1] if _n>1 & ape_modal2002==""
	gsort siren -ape_modal2008
	by siren: replace ape_modal2008 = ape_modal2008[_n-1] if _n>1 & ape_modal2008==""

	compress
	save "$temp/ficus_fare_modal_maf2rev1_naf2rev2", replace
			
			
*** Construct correspondance tables based on already converted ape codes (when the same ape2002 codes is converted into different ape2008 codes, keep the most frequent one)
	use "$temp/ficus_fare_modal_maf2rev1_naf2rev2", replace
	keep if ape_modal2008!="" & ape_modal2002!=""
	
	gcollapse (count) count_firms=year, by(ape_modal2008 ape_modal2002) //count the number of times a certain combination of ape and ape_old occurs 
	gsort ape_modal2002 -count_firms //highest count comes first, such that when conducting a merge the first one remains 
	by ape_modal2002: keep if _n==1  //only keep the 2002 code that occurs first in the sort --> because of previous line that's the 2002 code that occurs most frequently occurs for firms with any '
	//This is inverted from IMJ code who converts 2008 to 2002 codes
	keep ape_modal2008 ape_modal2002
	compress
	save "$temp/ape2002toape2008", replace
}
*
	
*===============================================================================
* Final harmonization
*===============================================================================
	
*** NB: Firms that have both codes have already an 08 code assigned throughout 
	use "$temp/ficus_fare_modal_maf2rev1_naf2rev2", replace

	** Now we need to deal with firms that died before 08 for which we need the crosswalk 
	merge m:1 ape_modal2002 using "$temp/ape2002toape2008",update 
	drop if _merge==2 //drop concorance lines (these dont have any data except concordance)

	* A few industry codes related to FIRE have no crosswalk despite the existence of an official crosswalk 
	replace ape_modal2008 = "6419Z" if  substr(ape_modal2002,1,3) == "651" & ape_modal2008 == ""
	replace ape_modal2008 = "9420Z" if  ape_modal2002 == "912Z" & ape_modal2008 == ""
	replace ape_modal2008 = "8430C" if  ape_modal2002 == "753C" & ape_modal2008 == ""
	replace ape_modal2008 = "0721Z" if  ape_modal2002 == "120Z" & ape_modal2008 == ""
	
	keep siren year ape_modal2008 
	rename ape_modal2008 ape 
	label var ape "Time invariant APE (naf-rev2)"
	
	* check ape is invariant within firm 
	sort siren year 
	by siren: gen test=1 if _n!=1 & ape!=ape[_n-1]
	assert test ==.
	drop test

	rename ape naf5
	compress
	save "$output/siren_naf2rev2_invariant_${fyear_all}_${lyear_all}", replace
	
}
*		


	
	
	
	
	
	
