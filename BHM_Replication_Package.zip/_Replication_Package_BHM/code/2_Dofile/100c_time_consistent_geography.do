


*===============================================================================
*===============================================================================
* GEOGRAPHY FILES (https://www.insee.fr/fr/information/6051727)
*===============================================================================
*===============================================================================

{

*** Change in commune code
	import delimited "$source_publ/mvtcommune_2022.csv",clear
	* destring commune code avant and apres 
	foreach var in com_av com_ap{
		gen dep = substr(`var',1,2) 
		
		* Adjust the department code for corsica (use 20)
		replace dep = "20" if dep=="2A" | dep=="2B"
		destring dep,replace 
		
		* create code communes
		gen commune = substr(`var',-3,.)
		destring commune,replace
		drop `var'
		gen `var' = dep*1000+commune
		drop dep commune
	}
	gen year_eff = substr(date_eff,1,4)
	destring year_eff ,replace
	keep com_av com_ap year_eff
	save "$temp/mvtcommune_2022",replace

*** bassin d'emploi 2010
	import excel using "$source_publ/bassin_emploi2010.xlsx",clear first  case(lower)
	keep codgeo ze2010
	// Geography 
	* department
	gen dep = substr(codgeo,1,2) 
	
	* Adjust the department code for corsica (use 20)
	replace dep = "20" if dep=="2A" | dep=="2B"
	destring dep,replace 
	
	* create code communes
	gen commune = substr(codgeo,-3,.)
	destring commune,replace
	replace commune = dep*1000+commune
	drop codgeo
	save "$temp/bassin_emploi2010",replace
	
	
	
}
*

*-------------------------------------------------------------------------------
* Crosswalk postal code - insee code (almost always different)
*-------------------------------------------------------------------------------

* https://www.data.gouv.fr/datasets/communes-de-france-base-des-codes-postaux/

	import delimited "$source_publ/20230823-communes-departement-region.csv",clear

	* readjust code insee for corsica 	
	replace code_commune_insee = "20"+ substr(code_commune_insee,-3,.) ///
		if inlist(substr(code_commune_insee,2,1),"A","B")
		
	destring code_commune_insee,replace 
	count if code_commune_insee != code_postal
	count if code_commune_insee == code_postal
	
	keep code_commune_insee code_postal
	rename (code_commune_insee code_postal) (commune_insee commune_postal)
	save "$temp/code_commune_insee_postal",replace

	
*===============================================================================	
*===============================================================================
* Time consistent commune code 
*===============================================================================
*===============================================================================
{
	
*===============================================================================
* Handle changes in commune code in ficus-fare  
*===============================================================================

*** Extract all the communes in ficus-fare and append
	local fyear ${fyear_all}
	local lyear ${lyear_all}
	
	clear
	forval yr = `fyear'/`lyear'{
		display in red "ficus-fare `yr'"
		append using "$temp/ficus_fare_nofilter_`yr'", keep(siren commune year)
	}
	save "$temp/temp",replace
	
*** Extract code commune in SIRENE stock to fill missing in ficus-fare
	use siren year depcom_siege ///
		using "$output/stocks_geography" if year>=${fyear_all} & year<=${lyear_all},clear

	rename depcom_siege commune_sirene 
	
	* readjust code insee for corsica 	
	replace commune_sirene = "20"+ substr(commune_sirene,-3,.) ///
		if inlist(substr(commune_sirene,2,1),"A","B")
	destring commune_sirene,replace 
	tempfile sirene 
	save `sirene'
	
	
*** Basic cleaning: handle mistakes (change between t-1 and t+1)
	use "$temp/temp",replace 
	gen missing 	= (substr(string(commune),-3,.)=="999") | length(string(commune))<=3 | commune==.
	
	** Bring sirene stock 
	preserve 
		keep if missing ==1
		merge 1:1 siren year using `sirene', keep(1 3)
		replace commune = commune_sirene if _merge==3 
		drop _merge
		tempfile temp 
		save `temp'
	restore 
	drop if missing ==1 
	append using `temp'
	
	* A few codes are obvious problems related to Marseille 
	* To simplify in general, remove the arrondissements for Paris, Marseille and Lyon 
	replace commune = 75056 if floor(commune/1000)==75 // adjust code commune paris
	replace commune = 13055 if floor(commune/100)==132 // adjust code commune marseille
	replace commune = 13055 if floor(commune/100)==133 // Marseille being complicated again...	
	replace commune = 69123 if floor(commune/100)==693 // adjust code commune Lyon

	* Some obvious mistakes for DomTom 
	replace commune = 97133 if commune == 97123
	replace commune = 97801 if commune == 97127
	
	sort siren year 
	replace commune=commune[_n-1] if commune!=commune[_n-1] & siren==siren[_n-1] & commune!=commune[_n+1] & siren==siren[_n+1] & commune[_n-1]==commune[_n+1]
	

	* Drop firms that have ALL observations missing commune 
	gegen totmiss	= sum(missing),by(siren)
	gegen nbobs		= sum(1),by(siren)
	drop if totmiss/nbobs ==1
	drop nbobs 
	
	* Only keep the problematic firms to speed up 
	preserve 
		keep if totmiss>=1
		sort siren year
		* Forward fill 
		by siren: replace commune=commune[_n-1] if _n>1 & missing==1
		
		* Backward fill 
		gsort siren -year
		by siren: replace commune=commune[_n-1] if _n>1 & missing==1 
		replace commune=. if missing==1
		tempfile temp 
		save `temp'
	restore 
	* bring back the cleaned commune  
	drop if totmiss>=1
	append using `temp'
	drop totmiss 
	
	save "$temp/list_commune_ficus_fare_raw",replace 
	
	
*** To simplify the process, remove all communes that are in the last year of the panel 
	* by definition this is the latest code 
	use "$temp/list_commune_ficus_fare_raw",replace 

	gegen lyear = max(year),by(commune)
	drop if lyear ==${lyear_all}
	gduplicates drop commune, force
	keep commune lyear 
	gen commune_ff = commune 
	label var commune_ff "Original code ficus-fare"
	save "$temp/commune_to_check",replace 
	
*** Among these communes, some still have the latest possible code but just the firm disappeared 
	* --> remove them too 
	use com_ap year_eff using "$temp/mvtcommune_2022"	,clear
	* for each commune, keep the latest code 
	sort com_ap year_eff 
	by com_ap : keep if _n==_N 
	
	rename com_ap commune 
	merge 1:1 commune using "$temp/commune_to_check",nogen keep(2)
	keep commune commune_ff lyear 
	save "$temp/commune_to_check",replace 

*** Now we are left with 345 communes with a code that changed 
	use "$temp/commune_to_check",replace 
	* drop two weird cases
	drop if commune == 94.33 // this is actually a foreign firm with no address in france  
	rename commune com_av 
	merge 1:m com_av using "$temp/mvtcommune_2022", keep(1 3) keepusing(com_ap)
	replace com_av = com_ap if _merge==3 
	rename com_av commune 
	drop com_ap 
	/*
		And actually 329 communes not matched ...
	*/
	gen commune_insee = commune  if _merge==1
	drop _merge
	joinby commune_insee using "$temp/code_commune_insee_postal",unmatched(master)
	ta _merge if commune_insee!=.
	/*
		we can find 301 communes
		61 are still unknown codes 
		
		A manual inspection of the siren that have the remaining weird codes indicates
		that these are foreign firms with addresses in a foreign country according to 
		societe.com 
		So I have no clue how the insee assigned a code ... 
		
	*/
	replace commune = commune_postal if _merge==3 
	keep commune_ff commune 
	save "$temp/crosswalk_communeff_communeclean",replace 
	
	
*===============================================================================
* Final dataset: ficus-fare with cleaned time invariant commune code 
*===============================================================================

*** Assign cleaned code commune 	
	use siren year commune using "$temp/list_commune_ficus_fare_raw",replace 
	rename commune commune_ff 
	merge m:1 commune_ff using "$temp/crosswalk_communeff_communeclean",nogen keep(1 3)
	replace commune = commune_ff if commune == .
	drop if commune == 94.33
	drop commune_ff 
	
*** Use time invariant definition 
	sort siren year 
	by siren: replace commune = commune[_n-1] if _n>1
	
	label var commune "Code commune (invariant)"
	
	save "$output/siren_commune_invariant_${fyear_all}_${lyear_all}",replace 
}
*	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	




