
*===============================================================================
* CONSTRUCT CEO VARIABLES
*===============================================================================
{
use  "$source_publ/shareholders/entities_clean", clear 

*------------------------------------------------------------
* A - Multiple CEOs -> keep the most frequent per SIREN
* If all documents mention multiple CEOs, multiple CEOs are retained
*------------------------------------------------------------
* One tag per CEO per document
bys siren id name_clean: egen _tag_ceo_doc = max(is_ceo)
bys siren id name_clean: replace _tag_ceo_doc = 0 if _n>1

* How many documents of this SIREN mention each CEO?
bys siren name_clean: egen ceo_freq = total(_tag_ceo_doc)

* CEOs per document and max frequency among those CEOs
bys siren id: egen n_ceo_doc       = total(is_ceo)
bys siren id: egen max_ceo_freq_doc = max(cond(is_ceo, ceo_freq, .))

* Flag the CEO rows that will be deleted
gen drop_ceo = is_ceo & n_ceo_doc>1 & ceo_freq<max_ceo_freq_doc
        /* (the "all-tie" case is automatically excluded) */
		
* For each (id,year0,name) group, record whether its CEO is dropped
bys id year0 name_clean: egen drop_flag = max(drop_ceo)

* On the shareholder row for that same person, zero the shareholder-CEO flag
replace shareholder_ceo     = "False" if !is_ceo & drop_flag
replace shareholder_ceo_num = 0 if !is_ceo & drop_flag

* Drop extra CEOs
drop if drop_ceo

* Clean-up helpers
drop _tag_ceo_doc max_ceo_freq_doc n_ceo_doc drop_ceo drop_flag ceo_freq

*------------------------------------------------------------
* B - Preparation of variables
*------------------------------------------------------------

* French dummy
gen nat_up = strupper(trim(nationality))
gen is_french = ///
        (substr(nat_up,1,2) == "FR")  | ///
        regexm(nat_up,"FRENCH")       | ///
        regexm(nat_up,"FRANCE")       | ///
        regexm(nat_up,"FRANCO")        
replace is_french = . if nationality == ""

* Age
gen  bdate = daily(birthdate, "YMD")       // "1964/09/21" → 21sep1964
format bdate %tdDD/NN/CCYY
gen  refdate = mdy(12, 31, year0)
* exact age (fractional), then floor to completed years
gen  age = floor((refdate - bdate)/365.25)
replace age = . if age<15 | age>99
drop bdate refdate

* Extract department from zipcode
foreach x in birth residence hq {
	rename `x'_zipcode `x'_zip
	gen `x'_dep = substr(`x'_zip,1,2) if length(`x'_zip)==2 | length(`x'_zip)==5
	replace `x'_dep = substr(`x'_zip,1,1) if length(`x'_zip)==1 | length(`x'_zip)==4
	destring `x'_dep, replace force
	replace `x'_dep = . if `x'_dep==0 | `x'_dep>97
}

* Destring zipcode
foreach x in birth residence hq {
	destring `x'_zip, replace force
}


*------------------------------------------------------------
* C- Variables of interest
*------------------------------------------------------------

*--------------------------------------------------------------------
* 0.  Focus on documents with a complete shareholder base
*--------------------------------------------------------------------
keep if value_ok & any_val_info_doc & !missing(capital)

*--------------------------------------------------------------------
* 1.  Document-level flags and counts
*--------------------------------------------------------------------

* At least one CEO-shareholder?
bys id year0: egen  has_shceo = max(shareholder_ceo_num)
lab var has_shceo "At least one CEO-shareholder"

* Number of CEO rows (any type)
bys id year0: egen  n_ceo = total(is_ceo)
lab var n_ceo "Number of CEOs"

* Number of shareholder-CEO rows (the ones that actually hold shares)
bys id year0: egen  n_shceo = total(shareholder_ceo_num & is_shareholder)
lab var n_shceo "Number of CEO-shareholders"


*--------------------------------------------------------------------
* 2.  Total capital stake held by CEO-shareholders
*--------------------------------------------------------------------
* fraction_equity is filled only on the shareholder rows
bys id year0: egen double fraction_equity_ceo = ///
    total( cond(shareholder_ceo_num & is_shareholder, fraction_equity, .) )
lab var fraction_equity_ceo "CEO's ownership share"

*--------------------------------------------------------------------
* 3.  Attributes copied only when there is exactly ONE CEO
*--------------------------------------------------------------------
gen byte _solo_ceo = is_ceo
bys id year0: replace _solo_ceo = 0 if n_ceo != 1      // lone-CEO flag

* List every source variable you need from the CEO row
local ceovars age is_french residence_zip residence_dep birth_zip birth_dep gender cat ///
              hq_zip hq_dep entity_siren

foreach v of local ceovars {

    * Step A – mark the CEO row with that variable's value
    bysort id year0 (_solo_ceo): gen `v'_ceo = `v' if _solo_ceo

    * Step B – copy the CEO value to every row in the document
    by id year0: replace `v'_ceo = `v'_ceo[_N]
}

gen male_ceo = gender_ceo=="Male" if gender_ceo~=""

lab var age_ceo				"CEO age"
lab var is_french_ceo		"CEO is French"
lab var residence_zip_ceo	"CEO residence zipcode"
lab var residence_dep_ceo	"CEO residence department"
lab var birth_zip_ceo		"CEO birth zipcode"
lab var birth_dep_ceo		"CEO birth department"
lab var gender_ceo			"CEO gender"
lab var male_ceo			"Male CEO"
lab var cat_ceo				"CEO is individual or company"
lab var hq_zip_ceo			"HQ zipcode"
lab var hq_dep_ceo			"HQ department"

*--------------------------------------------------------------------
* 4.  Collapse to one observation per document
*--------------------------------------------------------------------
* Keep only one row per id × year0 – the first is fine
bys id year0 (name_clean): keep if _n == 1

*--------------------------------------------------------------------
* 5.  Clean-up helper
*--------------------------------------------------------------------
drop _solo_ceo

local var_to_keep "siren year id year0 has_shceo n_ceo n_shceo fraction_equity_ceo age_ceo male_ceo is_french_ceo residence_zip_ceo residence_dep_ceo hq_zip_ceo hq_dep_ceo birth_zip_ceo birth_dep_ceo"
keep `var_to_keep'
order `var_to_keep'

drop if n_ceo == 0 // -> Zero info on CEOs
	  
sort siren year
save "$output/ceo_characteristics_clean", replace

}
*

*===============================================================================
* CONSTRUCT SHAREHOLDERS VARIABLES
*===============================================================================
{
use  "$source_publ/shareholders/entities_clean", clear 


*-------------------------------------------------------------------------------
* A - Prepare sample
*-------------------------------------------------------------------------------

* Focus on documents with a complete shareholder base
* Drop CEOs		
keep if value_ok & any_val_info_doc & !missing(capital)
drop if is_ceo

gegen sum_value_shares = sum(value_shares), by(year0 id)
gegen some_miss = max(value_shares==.), by(year0 id)
gen discrepancy = sum_value_shares - tot_val
su discrepancy, d
drop sum_value_shares some_miss discrepancy



*-------------------------------------------------------------------------------
* B - Cleaning & preparation of variables
*-------------------------------------------------------------------------------

*** Foreign

gen nat_up = strupper(trim(nationality))
gen is_french = ///
        (substr(nat_up,1,2) == "FR")  | ///
        regexm(nat_up,"FRENCH")       | ///
        regexm(nat_up,"FRANCE")       | ///
        regexm(nat_up,"FRANCO")        
replace is_french = . if nationality == ""


*** Age

gen  bdate = daily(birthdate, "YMD")       // "1964/09/21" → 21sep1964
format bdate %tdDD/NN/CCYY
gen  refdate = mdy(12, 31, year0)
* exact age (fractional), then floor to completed years
gen  age = floor((refdate - bdate)/365.25)
replace age = . if age<15 | age>99
drop bdate refdate

*** Extract department from zipcode

foreach x in birth residence hq {
	rename `x'_zipcode `x'_zip
	gen `x'_dep = substr(`x'_zip,1,2) if length(`x'_zip)==2 | length(`x'_zip)==5
	replace `x'_dep = substr(`x'_zip,1,1) if length(`x'_zip)==1 | length(`x'_zip)==4
	destring `x'_dep, replace force
	replace `x'_dep = . if `x'_dep==0 | `x'_dep>97
}


*-------------------------------------------------------------------------------
* C - Construct variables of interest
*-------------------------------------------------------------------------------

global list_of_var ""

*----------------------------
* Number of shareholders
*----------------------------

bys id year0: egen  n_shareholders = total(1)

lab var n_shareholders "Number of shareholders"
global list_of_var "$list_of_var n_shareholders"

*----------------------------
* Company sharehoders
*----------------------------

* Company indicator (true for *any* company-type row)
gen  _is_company = inlist(type,"shareholder_company","ceo_company")
bys id year0: egen  n_company = total(_is_company)
gen  frac_company = n_company / n_shareholders
drop _is_company

lab var frac_company "% corporate shareholders"
global list_of_var "$list_of_var frac_company"

// JH: There are shareholders recorded as companies (cat=="com") that looks like people. I noticed them because their zipcode is in residence_zipcode instead of hq_zipcode
distinct residence_zip hq_zip if cat=="com"
preserve
keep if cat=="com" & residence_zip~=""
l siren id name_clean cat gender birthdate if _n<=15
restore

*----------------------------
* Diversity of shareholders' residence
*----------------------------

* distinct residence departments 
bys id year0: egen  n_dept_dist = nvals(residence_dep)

* adjusted (0 = all shareholders in same dept, 1 = each in its own)
gen  dept_diversity = cond(n_shareholders>1, (n_dept_dist-1)/(n_shareholders-1), 0)

lab var dept_diversity "Diversity of shareholders residence departments"
global list_of_var "$list_of_var dept_diversity"

*----------------------------
* Shareholders' gender
*----------------------------

* Number of male shareholders
gegen n_male	= sum(gender=="Male"),	by(year0 id)

* Number of female shareholders
gegen n_female	= sum(gender=="Female"),by(year0 id)

* Number of shareholders with non-missing genders
gegen n_gender 	= sum(gender~=""), 		by(year0 id)

* All male shareholders?
gen all_male_shareholders = n_male==n_gender if n_gender>=2
lab var all_male_shareholders	"All male shareholders"

* All female shareholders?
gen all_female_shareholders = n_female==n_gender if n_gender>=2
lab var all_female_shareholders	"All female shareholders"

* Male & female shareholders?
gen male_female_shareholders = n_male<n_gender & n_female<n_gender if n_gender>=2
lab var male_female_shareholders	"Male & female shareholders"

drop n_male n_female n_gender

* Share of females
gen  _is_female = (gender=="Female")   if !missing(gender)
bys id year0: egen  n_female = total(_is_female)
gen  frac_female = n_female / n_shareholders
lab var frac_female "% female shareholders"
drop _is_female

global list_of_var "$list_of_var all_male_shareholders all_female_shareholders male_female_shareholders frac_female"

*----------------------------
* Shareholders' nationality
*----------------------------

gegen n_french	= sum(is_french==1),	by(year0 id)
gegen n_foreign	= sum(is_french==0),	by(year0 id)
gegen n_nati	= sum(is_french<.),		by(year0 id)

gen all_french_shareholders = n_french==n_nati if n_nati>=2
gen all_foreign_shareholders = n_foreign==n_nati if n_nati>=2
gen french_foreign_shareholders = n_french<n_nati & n_foreign<n_nati if n_nati>=2

lab var all_french_shareholders "All French shareholders"
lab var all_foreign_shareholders "All foreign shareholders"
lab var french_foreign_shareholders "Both French and foreign shareholders"

drop n_french n_foreign n_nati

* Non-French indicator
bys id year0: egen  n_nonfr = total(is_french==0)
gen  frac_nonfr = n_nonfr / n_shareholders

lab var frac_nonfr "% non-French shareholders"
global list_of_var "$list_of_var all_french_shareholders all_foreign_shareholders french_foreign_shareholders frac_nonfr"

*----------------------------
* Shareholders residing outside firm's department
*----------------------------

* Firm's department
	preserve 
		use "$output/siren_commune_invariant_${fyear_all}_${lyear_all}",replace 
		* commune is invariant so we can keep one obs per firm 
		gduplicates drop siren, force
		gen dep = floor(commune/1000)
		keep siren dep 
		tempfile siren_dep 
		save `siren_dep'
	restore 
	
* Make sure siren is 9 digit string 
tostring siren,replace 
replace siren = substr("00000000"+siren,-9,.)	
merge m:1 siren using `siren_dep', keep(1 3) nogen
rename dep firm_dep

* Dummy shareholder outside firm's department
gen outofdep = residence_dep != firm_dep & hq_dep != firm_dep if residence_dep != . | hq_dep != .

* Fraction of shareholders outside firm's department
gegen frac_shareholders_outofdep = mean(outofdep), by(id year0)
lab var frac_shareholders_outofdep "% shareholders outside firm's department"

* Fraction of shares
gegen frac_shares_outofdep = mean(outofdep) [aw=value_shares], by(id year0)
lab var frac_shares_outofdep "% shares outside firm's department"

drop firm_dep outofdep
global list_of_var "$list_of_var frac_shareholders_outofdep frac_shares_outofdep"

*----------------------------
* Family members
*----------------------------

* Extract last name from clean_name (which is of the form Lastname Firstname)
gen first_space = strpos(name_clean," ") if cat=="ind"
gen lastname = substr( name_clean, 1, first_space-1) if cat=="ind" & first_space-1>=3

* Deal with names like Le Coz Nicolas: define name_sub = "Coz Nicolas"
gen name_sub = substr( name_clean, first_space+1, .) if cat=="ind" & first_space-1<=2
gen second_space = first_space+1 + strpos(name_sub," ") if cat=="ind" & first_space-1<=2 & strpos(name_sub," ")>0
replace lastname = substr( name_clean, 1, second_space-1) if cat=="ind" & first_space-1<=2 & second_space<.

* Number of distinct last names
gegen tag_lastname = tag(year0 id lastname)
gegen n_dist_lastname = sum(tag_lastname), by(year0 id)
gegen n_lastname = sum(lastname~=""), by(year0 id)

* Number of distinct lastname names/Number of shareholders (with non-missing lastname name)
gen diversity_family = (n_dist_lastname-1) / (n_lastname-1) if n_lastname>1
lab var diversity_family "Diversity family (all family = 0; no family = 1)"

drop first_space name_sub second_space tag_lastname n_dist_lastname n_lastname
global list_of_var "$list_of_var diversity_family"

*----------------------------
* Dominant last-name equity share (capital-weighted)
*----------------------------

* Total capital by last name within each (id, year0); ignore missing lastnames
bys id year0 lastname: egen _fam_val = total(cond(lastname!="", value_shares, .))

* Tag each distinct (non-missing) lastname once
gegen byte _tag_ln = tag(id year0 lastname)
replace _tag_ln = 0 if lastname==""

* Family capital shares in total capital
gen double _fam_share = _fam_val / tot_val if _tag_ln

* Max equity share among last names (proxy for family control)
bys id year0: egen top_family_share = max(cond(_tag_ln, _fam_share, .))

gen _is_company = inlist(type,"shareholder_company","ceo_company") | (cat=="com")
bys id year0: egen _all_companies = min(_is_company)   // 1 if all rows are companies
replace top_family_share = 0 if missing(top_family_share) & _all_companies
drop _all_companies

label var top_family_share "Family ownership"
* Clean up
drop _fam_val _fam_share _tag_ln _is_company

* Track in your export list
global list_of_var "$list_of_var top_family_share"

*----------------------------
* HHI of value_shares
*----------------------------

* Share in total capital
gen  _vshare = value_shares / tot_val
gen  _vshare2 = _vshare^2

* HHI
bys id year0: egen  hhi_shares_raw = total(_vshare2)

* Adjusted HHI =  (HHI − 1/N)  /  (1 − 1/N)   (Hall-Tideman normalisation)
gen  hhi_shares_adj = cond(n_shareholders>1, (hhi_shares_raw - 1/n_shareholders) / (1 - 1/n_shareholders), .)

lab var hhi_shares_raw			"HHI ownership (raw)"
lab var hhi_shares_adj			"HHI ownership (adjusted)"

drop _vshare _vshare2
global list_of_var "$list_of_var hhi_shares_raw hhi_shares_adj"

*----------------------------
* Majority shareholder
*----------------------------

gen maj_sh = value_shares/tot_val >= 0.5 if value_shares/tot_val<.
gegen majority_shareholder = max(maj_sh), by(year0 id)
drop maj_sh
lab var majority_shareholder "Majority shareholder"

* Pooling family members together
gegen value_shares_pooled = sum(value_shares) if cat=="ind" & lastname~="", by(year0 id lastname)
replace value_shares_pooled = value_shares if cat=="com"
gegen majority_shareholder_pooled = max(value_shares_pooled/tot_val>=.5 & value_shares_pooled/tot_val<.), by(year0 id)
drop value_shares_pooled
lab var majority_shareholder_pooled "Majority shareholder block"

global list_of_var "$list_of_var majority_shareholder majority_shareholder_pooled"


*----------------------------
* Dispersion of shareholder ages
*----------------------------

bys id year0: egen  shareholder_age_sd = sd(age)
lab var shareholder_age_sd "S.D. of shareholders age"
global list_of_var "$list_of_var shareholder_age_sd"

*----------------------------
* Capital
*----------------------------

lab var capital "Capital (from bylaws)"
global list_of_var "$list_of_var capital"

*-------------------------------------------------------------------------------
* D - Collapse to 1 row per document & Save
*-------------------------------------------------------------------------------

bys id year0 (name_clean): keep if _n==1

keep siren year id year0 $list_of_var

sort siren year
save "$output/shareholders_characteristics_clean", replace

}
*
