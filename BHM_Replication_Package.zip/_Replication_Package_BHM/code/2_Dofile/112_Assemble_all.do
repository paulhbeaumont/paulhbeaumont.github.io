


*===============================================================================
* Assemble different industry characteristics 
*===============================================================================

	use "$temp/exposureReform_naf5",replace 
	merge 1:1 naf5 using "$temp/characteristicsPRE_naf5",nogen keep(3)
	save "$output/characteristics_naf5_all",replace 

*===============================================================================
*===============================================================================
* 	Outliers: baseline  
*===============================================================================
*===============================================================================
{
* Do it in a separate file to speed things up 		
global Y_list "Ktot Y L equity eqall at"   
* 
global IQRlist "1 2 3 4 5"
global Y_liststar "Ktot*e Y*e L*e equity*e eqall*e at*e"
*  

*-------------------------------------------------------------------------------
* 	New Firms
*-------------------------------------------------------------------------------

		
	use siren year $Y_liststar naf5 ///
		using "$temp/newfirms01" , replace 

	* Keep to pre / post time period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}
																
	foreach var in $Y_list   {	
		if inlist("`var'","equity", "at"){
			local tlist  "1 3"
		}
		if inlist("`var'","L","Y"){
			local tlist  "3"
		}				
		if "`var'" == "Ktot"{
			local tlist  "1 2 3 4 5"
		}		

		foreach t in `tlist' {  
							
			display in red "Processing: `var'`t'"
			
			quiet foreach meth in "_e" { 
							
				local varX "`var'`t'`meth'"			
			
				capture drop PERC*
				foreach x in 25 50 75{  
					gquantiles PERC`x' 		= `varX' , pctile percentiles(`x') strict 
				}
				
				foreach x in  25 50 75{
					gegen temp 		= max(PERC`x') 
					replace PERC`x' = temp if PERC`x' ==.
					drop temp*
				}
				** Definition of outlier: interquartile range 
				foreach num in $IQRlist { //1 2 3 4 
						
					capture drop *iqr*
					gen low_iqr 		= PERC50 - `num'*(PERC75 - PERC25)
					gen high_iqr 		= PERC50 + `num'*(PERC75 - PERC25)

					* Trimmed IQR
					if "`meth'"=="_e"{
						gen `varX'_`num'it = `varX'
						replace `varX'_`num'it  = . if `varX'_`num'it  <= low_iqr & `varX'_`num'it <.
						replace `varX'_`num'it  = . if `varX'_`num'it  >= high_iqr & `varX'_`num'it <.
					}
				}
			} // meth
		} // t
	} // var
	keep siren year *t  
	save "$temp/outliersBaseline_new", replace


*-------------------------------------------------------------------------------
* 	Incumbents
*-------------------------------------------------------------------------------

	use siren year *_Ktot3* naf5 ///
		using "$temp/incumbents01" , replace 
	
	* Keep to pre / post time period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}
																
	foreach START in 0 1 {
		foreach growth in g gl {
						
// 			local START 0 
// 			local growth g 
			
			local varX "`growth'`START'_Ktot3"	
			display in red "`varX'"
			sum `varX'
				
			capture drop PERC*
			foreach x in 25 50 75{  
				gquantiles PERC`x' 		= `varX' , pctile percentiles(`x') strict 
			}
			
			foreach x in  25 50 75{
				gegen temp 		= max(PERC`x') 
				replace PERC`x' = temp if PERC`x' ==.
				drop temp*
			}
			** Definition of outlier: interquartile range 
			foreach num in $IQRlist { //1 2 3 4 
					
				capture drop *iqr*
				gen low_iqr 		= PERC50 - `num'*(PERC75 - PERC25)
				gen high_iqr 		= PERC50 + `num'*(PERC75 - PERC25)

				* Trimmed IQR
				gen `varX'_`num'it = `varX'
				replace `varX'_`num'it  = . if `varX'_`num'it  <= low_iqr & `varX'_`num'it <.
				replace `varX'_`num'it  = . if `varX'_`num'it  >= high_iqr & `varX'_`num'it <.
			}
		} 
	}  
	keep siren year *t  
	save "$temp/outliersBaseline_inc", replace

}

*

*===============================================================================
*===============================================================================
* 	Outliers: robustness 
*===============================================================================
*===============================================================================
{
* Do it in a separate file to speed things up 		
global Y_list Ktot  
global IQRlist "3 5"
global Y_liststar "Ktot*"

*-------------------------------------------------------------------------------
* 	New Firms
*-------------------------------------------------------------------------------

	use siren year $Y_liststar naf5 ///
		using "$temp/newfirms01" , replace 

	* Keep to pre / post time period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}
																
	foreach var in $Y_list   {				
		if "`var'" == "Ktot"{
			local tlist  "3"
		}		

		foreach t in `tlist' {  
							
			display in red "Processing: `var'`t'"
										
			local varX "`var'`t'_e"			
		
			capture drop PERC*
			foreach x in 1 25 50 75 95 99{  
				gquantiles PERC`x' 		= `varX' , pctile percentiles(`x') strict 
			}
			
			foreach x in  1 25 50 75 95 99{
				gegen temp 		= max(PERC`x') 
				replace PERC`x' = temp if PERC`x' ==.
				drop temp*
			}
			** Definition of outlier: interquartile range 
			foreach num in $IQRlist {  
					
				capture drop *iqr*
				gen low_iqr 		= PERC50 - `num'*(PERC75 - PERC25)
				gen high_iqr 		= PERC50 + `num'*(PERC75 - PERC25)

				* Trimmed IQR
				gen `varX'_`num'it = `varX'
				replace `varX'_`num'it  = . if `varX'_`num'it  <= low_iqr & `varX'_`num'it <.
				replace `varX'_`num'it  = . if `varX'_`num'it  >= high_iqr & `varX'_`num'it <.
				* Winsorized IQR
				gen `varX'_`num'i = `varX'
				replace `varX'_`num'i  = low_iqr if `varX'_`num'i <= low_iqr & `varX'_`num'i <.
				replace `varX'_`num'i  = high_iqr if `varX'_`num'i >= high_iqr&`varX'_`num'i <.					
			}
			** Definition of outlier: tails  
			foreach x in 95 99{  
				* Winsorized
				gen `varX'_`x'w = `varX'
				replace `varX'_`x'w  	 = PERC`x' if `varX'_`x'w  >= PERC`x' & `varX'_`x'w <.
				recode `varX'_`x'w  	.= 0
			
				* Trimmed  
				gen `varX'_`x't 		= `varX'
				replace `varX'_`x't  	= . if `varX'_`x't  >= PERC`x' & `varX'_`x't <.
			}				
		} // t
	} // var
	keep siren year *t *i *w
	save "$output/outliersRobust_new", replace
}
*

*===============================================================================
*===============================================================================
* Merge all the different datasets together and produce final working sample
*===============================================================================
*===============================================================================
{
	
*** New 	
	use "$temp/newfirms01", clear
	gen sample = "new"
	merge m:1 naf5 using "$output/characteristics_naf5_all",nogen keep(3)
	
	** Define fixed effects 
	gegen naf2year 	= group(naf2 year)
	gegen geoyear 	= group(${geo} year)
	
	** Restrict to working sample period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}
							
	** Impose minimum number of firm created in each cell 		
	foreach th in 0 { //100
		preserve 
			keep if entry_tot_m >=`th'
			
			** Bring cleaned LHS 
			merge 1:1 siren using "$temp/outliersBaseline_new", ///
			nogen keep(3)  
			
			** Size and share sas
			gen size 		= ${SIZE}
			gen s_sas 		= ${s_sasDEF}
			
			* Exposure to the reform	
			local Z $exposure 
			qui su `Z'    
			gen Z 			= `Z' / r(sd) 			
			gen Z_post 		= `Z' / r(sd) * (year>2008)
			label var Z_post	 "\addlinespace Exposure\(\times\)Post"		
				
			save "$output/new_inc_workingsample_th`th'", replace
		restore 	
	}
	
*** Incumbents
	use "$temp/newfirms01", clear
	gen sample = "new"
	append using "$temp/incumbents01"
	merge m:1 naf5 using "$output/characteristics_naf5_all",nogen keep(3)
	
	** Define fixed effects 
	gegen naf2year 	= group(naf2 year)
	gegen geoyear 	= group(${geo} year)
	
	** Size and share sas
	gen size 		= ${SIZE}
	gen s_sas 		= ${s_sasDEF}
	
	** Restrict to working sample period 
	keep if year>=${fyear_sample} & year<=${lyear_sample}
	
	** K/e ratio 
	gen Ke = Ktot1/equity1 
	winsor4 Ke,outlier(tail) level(5) method(winsor)

	gen Keqall = Ktot1/eqall1 
	winsor4 Keqall,outlier(iqr) level(5) method(winsor) 	
		
	** Restrict to useful variables 
	keep $fe_reg_list $cluster Ke Keqall siren year sample sas_var0 sas_var1
				
	* Exposure to the reform	
	local Z $exposure 
	qui su `Z'   if sample == "new"
	gen Z_post 		= `Z' / r(sd) * (year>2008)
	label var Z_post	 "\addlinespace Exposure\(\times\)Post"		
	drop sample 
	
	* Bring incumbents RHS  
	merge 1:1 siren year using "$temp/outliersBaseline_inc",nogen keep(3)

	save "$output/incumbents_workingSample",replace
}
*
