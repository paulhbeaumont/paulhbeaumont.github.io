
/*==============================================================================

This code cleans provisions and save them at the document level.

==============================================================================*/

*===============================================================================
* Extract legal form for merge with bylaws 
*===============================================================================

	use siren sas sas_var* using "$temp/newfirms01", clear
	egen eversas = rowmax(sas_var0 sas_var1 sas_var2 sas_var3)
	keep siren eversas sas_var0
	save "$temp/dummy_sas", replace	

*===============================================================================
* PROVISIONS AT THE DOCUMENT LEVEL
*===============================================================================

use "$source_publ/bylaws/bylaws_doc_00", clear
	* make sure siren is 9 digit string 
	tostring siren,replace
	replace siren = substr("0000"+siren,-9,.)


******* Number of initial shareholders
rename n_shareholders n_ini_shareholders
* We only keep the first non-missing occurence (if any) of the variable per siren 
* carry forward first non-missing observation
gsort siren year id
by siren: replace n_ini_shareholders = n_ini_shareholders[_n-1] if n_ini_shareholders[_n-1]<.
* carry backward first non-missing observation
gsort siren -year
by siren: replace n_ini_shareholders = n_ini_shareholders[_n-1] if n_ini_shareholders==.

******* Multiple share classes

drop msc_pref msc_cat
lab var msc "Multiple share classes"

******* Preferred dividend rights

lab var pref_div1_prio "Dividende prioritaire"
lab var pref_div2_precip "Dividende préciputaire"
lab var pref_div3_major "Dividende majoré"
lab var pref_div4_linear "Linear dividend rule"
lab var pref_div5_restr "Restricted dividend"
lab var pref_div6_other "Other preferred dividend"
lab var pref_div_cumul "Cumulative preferred dividend"

gen ms_div = max(pref_div1_prio, pref_div2_precip, pref_div3_major, pref_div4_linear, pref_div5_restr, pref_div6_other, pref_div_cumul) // previously named pdiv
lab var ms_div "Differential dividend rights"

gen ms_div_prio = max(pref_div1_prio, pref_div2_precip)
gen ms_div_lin = max(pref_div3_major, pref_div4_linear)
gen ms_div_oth = max(pref_div5_restr, pref_div6_other)


******* Other cash-flow rights

rename	pref_liq ms_liq
lab var ms_liq "Preferred liquidation rights"

rename	pref_ces ms_cashout
lab var ms_cashout "Preferred cash-out rights"

******* Control rights

rename	pref_ceo ms_ceo
lab var ms_ceo "Preferred CEO appointment rights"

rename	pref_board ms_board
lab var ms_board "Preferred board appointment rights"

rename	diff_voting_rights ms_vot
lab var ms_vot "Preferred voting rights"

******* Preemptive rights

lab var preemp "Preemptive rights in share transfers"

rename	preemp_msc ms_preemp
lab var ms_preemp "Differential preemptive rights  in share transfers"

******* Share issuance priority rights

lab var prio_issuance  "Share issuance priority rights"

******* Restricted subscription

rename exclusion_msc ms_exclusion
lab var ms_exclusion "Differential shareholder exclusion rights"

******* Share transfer restrictions

rename transfer_approval_msc ms_transfer_approval
lab var ms_transfer_approval "Preferred transfer approval rights"
lab var transfer_approval "Transfer approval rights"

******* Lockup periods
lab var lockup "Presence of lockup period"
lab var lockup_length "Length of lockup period"
lab var lockup_date "End date of lockup period"

*Transfer approval = 0 means freely tradable shares
gen free = transfer_approval == 0  if transfer_approval<.
lab var free "Freely tradable shares"

replace transfer_approval = transfer_approval>0 if transfer_approval<.

lab var tag "Tag-along"
lab var drag "Drag-along"
lab var tagdrag "Tag-along or Drag-along"
lab var buyorsell "Buy or sell"
lab var antidilut "Anti-dilution"
lab var rofr "Right of first refusal"
lab var rofo "Right of first offer"
lab var noncomp "Non-compete"

gen protection = max(preemp,prio_issuance,transfer_approval,tagdrag, ///
buyorsell,antidilut,rofr,rofo,noncomp)
label var protection "Any shareholder protection"

******* Board of directors

rename	conseil_admin board_dir
lab var board_dir "Board of directors"

rename	conseil_strat strat_comm
lab var strat_comm "Strategic committee"

rename	conseil_gestion gestion_comm
lab var gestion_comm "Steering committee"

gen board_total = max(board_dir,strat_comm,gestion_comm)
lab var board_total "Board of directors"

******* Advisory boards

rename	conseil_surv adv_board
lab var adv_board "Advisory board"

****** Management committees

rename	conseil_operation ope_comm
lab var ope_comm "Operating committee"

rename	conseil_direction mana_comm
lab var mana_comm "Management committee"

rename	conseil_executif exe_comm
lab var exe_comm "Executive committee"

gen executive_total = max(ope_comm,mana_comm,exe_comm)
lab var executive_total "Executive committee"

gen governance = max(board_total,executive_total,adv_board)
lab var governance  "Any governance body"

****** Equity issuance

rename	emission equity_issuance
lab var equity_issuance "Equity issuance"

rename	bsa warrant
lab var warrant "Share warrants"

******** Franchises

lab var itm "Intermarché"
lab var u "Super U"

******** Shareholders characteristics

lab var n_ini_shareholders "Number of initial shareholders"
lab var shareholder_agreement_1 "Shareholder agreement (strict)" 
lab var shareholder_agreement_2 "Shareholder agreement (large)" 
lab var new_shareholder "New shareholder"
rename no_preferred_subscription no_pref_subscription
lab var no_pref_subscription "Preferred subscription rights waiver"

******** Generic SAS features

lab var dg "CEO delegation"
lab var ad_nutum "Unconditional CEO termination"
lab var exclusion "Shareholder exclusion"
lab var personne_morale "Firm as president"
lab var suspension "Removal of voting rights"

************************* MISSING VALUES ***************************************

*** LIST OF PROVISIONS

*Governance-related clauses
global governance board_dir strat_comm gestion_comm board_total ///
 adv_board ope_comm mana_comm exe_comm executive_total governance
 
*Governance-related clauses, specific to SAS
global governance_sas board_total executive_total

*Other SAS-specific clauses
global generic_sas ad_nutum dg personne_morale suspension 

*Multiple share classes
global msc msc ms_div ms_liq ms_cashout ms_ceo ms_board ms_vot ms_preemp ///
 ms_exclusion ms_transfer_approval

*Replace missing with zeros for variables obtained on Bylaws_Doc
* and that are only defined if the corresponding clause == 1
qui foreach var in shareholder_agreement_1 shareholder_agreement_2 new_shareholder ///
no_pref_subscription {
	replace `var' = 0 if `var' == .
} 

* How to handle missing values for some clauses that heavily rely on the article structure?
* Ex: preemp, prio_issuance...
* I think the presence of an article about share transfer (for instance) is a decision of the firm
* So if we do not find any such article, that means the firm did not include the clause 
* (some false negatives but that's fine)
* However, those variables are not defined if the document is not structured in articles

qui foreach var in equity_issuance $governance prio_issuance transfer_approval lockup /*
*/ exclusion ad_nutum dg personne_morale suspension ms_ceo /*
*/ ms_board ms_exclusion preemp ms_preemp ms_transfer_approval free {
	replace `var' = 0 if `var' == .
	replace `var' = . if article == 0
} 


**** Force to 0 if forbidden features in SARL 
	merge m:1 siren using "$temp/dummy_sas", keep(1 3) nogen keepusing(eversas)
	di "Number of obs with forbidden features with warrant"
	replace warrant = 0 if eversas==0

* Force special rights of multiple share classes to 0 if the firms does not have multiple share classes
qui foreach var in ms_div ms_liq ms_cashout ms_ceo ms_board ms_vot ms_preemp ///
 ms_exclusion ms_transfer_approval {
 	di "Number of obs with differential rights but no multiple share classes with `var'"
 	replace `var' = . if msc==0 & `var' == 1
	replace `var' = . if msc==0
}

* List of provisions
ds siren year year0 id lockup_length lockup_date capital nb_parts prix_part article, not
global list_features `r(varlist)'

* Percent (x100)
qui foreach var in $list_features {
	gen pct_`var' 			= `var' * 100
}

*** LABELS

* Multiple share classes
label var pct_msc "Multiple share classes"
gen pct_msc_sas = pct_msc if eversas
label var pct_msc_sas "Multiple share classes (flexible bylaws)"

* MSC: Cash-flow rights
gen pct_any_cf = max(ms_liq,ms_div,ms_cashout)*100
gen pct_residual = max(ms_div,ms_cashout)*100
lab var pct_any_cf "With differential cash-flow rights"
lab var pct_residual "\quad Differential residual cash-flow rights"
lab var pct_ms_liq "\quad Differential liquidation rights"
lab var pct_ms_div "\quad\quad Differential dividend rights"
lab var pct_ms_cashout "\quad\quad Differential cash-out rights"

* MSC: Control rights
gen pct_any_ctrl = max(ms_board,ms_ceo,ms_vot,ms_exclusion)*100
lab var pct_any_ctrl "With differential control rights"
lab var pct_ms_board "\quad Differential board appointment rights"
lab var pct_ms_ceo "\quad Differential CEO appointment rights"
lab var pct_ms_vot "\quad Differential voting rights"
lab var pct_ms_exclusion "\quad Differential exclusion rights"

* MSC: Subscription rights
gen pct_any_sr = max(ms_transfer_approval,ms_preemp)*100
lab var pct_any_sr "With differential subscription rights"
lab var pct_ms_transfer_approval "\quad Differential transfer approval rights"
lab var pct_ms_preemp "\quad Differential preemptive rights"

*Protection of shareholders
lab var pct_lockup "Lockup period"
lab var pct_preemp "Preemptive rights"
lab var pct_prio_issuance  "Share issuance priority rights"
lab var pct_transfer_approval "Transfer approval rights"
lab var pct_free "Freely tradable shares"
lab var pct_tag "Tag-along"
lab var pct_drag "Drag-along"
lab var pct_tagdrag "Tag-along or Drag-along"
lab var pct_buyorsell "Buy or sell"
lab var pct_antidilut "Anti-dilution"
lab var pct_rofr "Right of first refusal"
lab var pct_rofo "Right of first offer"

*Governance
lab var pct_governance "Governance entity"
lab var pct_board_total "\quad Board of directors"
lab var pct_adv_board "\quad Advisory board"
lab var pct_executive_total "\quad Executive committee"

qui foreach var of varlist pct_governance pct_board_total pct_adv_board pct_executive_total {
	gen `var'_sas = `var' if eversas  
}
drop eversas 

*Governance - SAS
lab var pct_governance_sas "\quad Governance entity (flexible bylaws)"
lab var pct_board_total_sas "\quad Board of directors (flexible bylaws)"
lab var pct_adv_board_sas "\quad Advisory board (flexible bylaws)"
lab var pct_executive_total_sas "\quad Executive committee (flexible bylaws)"

*Other governance
lab var pct_exclusion "Shareholder exclusion"
lab var pct_suspension "Suspension of voting rights"
lab var pct_ad_nutum "Ad nutum CEO termination"
lab var pct_dg "Appointment of directors by the CEO" 

*Equity issuance
lab var pct_equity_issuance "Equity issuance"
lab var pct_warrant "Share warrants"

*Shareholders
lab var n_ini_shareholders "Number of initial shareholders" 
lab var pct_shareholder_agreement_1 "Shareholder agreement (strict)" 
lab var pct_shareholder_agreement_2 "Shareholder agreement (large)" 
lab var pct_new_shareholder "New shareholder"
lab var pct_no_pref_subscription "Preferred subscription rights waiver" 

*Others
lab var pct_noncomp "Non-compete"
lab var pct_personne_morale "Company as CEO"

*Any deviation? 
gen any_deviation = max(msc,ad_nutum,dg,free,suspension,warrant,board_total, ///
executive_total,preemp,adv_board,tag,drag,tagdrag,buyorsell, ///
antidilut,rofr,rofo,noncomp,lockup,prio_issuance,exclusion) if article == 1

save "$temp/bylaws_doc_01", replace

