



*-------------------------------------------------------------------------------
* Correspondance tables for a138 to naf2 rev2
*-------------------------------------------------------------------------------
* https://www.insee.fr/fr/information/2028155

*** Get full list of 2 and 3 digit naf2 rev2 
	import excel "${source_publ}/naf2008_5_niveaux.xls", first case(lower) clear 
	keep niv3 niv2 
	rename (niv3 niv2) (naf3 naf2)
	replace naf3 = subinstr(naf3, ".", "", .)
	save "${temp}/temp", replace
	
*** Bring the naf3 to the correspondance table to handle cases where the naf2-rev2 is reported as 2 digit instead of 3 digit 
	import delimited "${source_publ}/input_output/passage_a137.csv", delimiter(";") varnames(1) clear 
	replace code_a138 = substr(code_a138,2,length(code_a138))
	
	* Make sure that naf2rev2 has three digit 
	tostring naf_rev2,replace 

	* first handle true 1 digit
	replace naf_rev2 = "0"+naf_rev2 if length(naf_rev2)==1

	keep code_a138 naf_rev2
	
	gen naf2  = naf_rev2 if length(naf_rev2)==2
	
	joinby naf2 using "${temp}/temp",unmatched(master)
	
	replace naf3 = naf_rev2 if  naf3==""
	keep code_a138 naf3 
	destring naf3,replace
save "${temp}/tab_passage", replace



*-------------------------------------------------------------------------------
* IO matrix in 138 industries 
*-------------------------------------------------------------------------------

import delimited "${source_publ}/input_output/io_2017.csv", delimiter(";") varnames(1) clear 

* IO is in N x N matrix form, put that in panel form 
rename * var*
rename varbranches row_from
reshape long var, i(row_from) j(col_to) string
rename (row_from col_to var) (from to value)
replace to = upper(to)

* Now we can construct shares of consumption 
gegen total = sum(value),by(to)
gen share = value/total

*-------------------------------------------------------------------------------
* Program to convert A138 codes to NAF3 and aggregate
*-------------------------------------------------------------------------------

cap program drop convert_a138_to_naf3
program define convert_a138_to_naf3
    args varname newname groupvars
    
    rename `varname' code_a138
    joinby code_a138 using "${temp}/tab_passage", unmatched(master)
    drop if _merge == 1
    drop _merge
    rename code_a138 `varname'
    
    * In case of 1 to n mapping, divide by 1/N to preserve total value
    bys `groupvars': gen nb = _N
    replace value = value/nb
    drop nb
    
    gcollapse (sum) value, by(`groupvars' naf3)
    rename naf3 `newname'
end


*** Convert destination (to) from A138 to NAF3
convert_a138_to_naf3 to naf_to "from to"

*** Convert origin (from) from A138 to NAF3  
convert_a138_to_naf3 from naf_from "naf_to from"

save "${output}/io_2017", replace


