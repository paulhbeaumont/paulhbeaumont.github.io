


*===============================================================================
*===============================================================================
* Create single file for each cohort 
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Extract raw data 
*-------------------------------------------------------------------------------


*===============================================================================
* SINE 2006
*===============================================================================

foreach year in 2006  {
	local x = `year'-2000
	cd "${rawdatadir}\SINE_SINE_`year' - situation initiale"
	import sas "profil0`x'.sas7bdat", clear
	rename *, lower
	cap gen year = `year'		
	rename sirena siren

	* Make sure siren is 9 digit 
	replace siren=substr("0000"+siren,-9,.) 
	drop if siren=="000000000"|siren==""
	duplicates drop siren, force

	order *ape*
	tab  chgapea
	sort chgapea  
	gen apen2=apeca if chgapea=="1"|chgapea=="2"
	drop chgapea apeca
	order *ape*


*-------------------------------------------------------------------------------
* Format data 
*-------------------------------------------------------------------------------

	replace diploea="10" if diploea=="0" // reclassifie les grandes ecoles
	replace diploea="nn" if diploea=="0"
	
	tab typcre6a
	gen typcrea="1" if typcre6a=="1"|typcre6a=="3" // rachat employeur/tiers
	replace typcrea="2" if typcre6a=="2" // heritage et reprise conjoint
	replace typcrea="4" if typcre6a=="4" // gerance
	replace typcrea="5" if typcre6a=="5" // creation nouvelle
	drop typcre6a
	tab typcrea
	
	* Motives
	rename (mot1a mot2a mot3a mot4a mot5a mot6a mot7a mot8a mot9a) ///
	(motiv61a motiv62a motiv63a motiv64a motiv65a motiv66a motiv67a motiv68a motiv69a)
	drop motiv6a
	rename (crqui61a crqui62a crqui63a crqui64a crqui65a crqui66a) ///
	(crqui01a crqui02a crqui03a crqui04a crqui05a crqui06a)
	gen  crqui07a=crqui06a
	replace crqui07a="7" if crqui06a=="6"
	replace crqui06a="n" 

	save "$temp/sine_`year'", replace

}
*	
	
*===============================================================================
* SINE 2010
*===============================================================================


foreach year in 2010  {
// 	local year 2010
	cd "${rawdatadir}\SINE_SINE_`year' - situation initiale"
	import sas "sine`year'_diffusion.sas7bdat", clear
	rename *, lower
	cap gen year = `year'		
	* Make sure siren is 9 digit 
	rename sirena siren
	replace siren=substr("0000"+siren,-9,.) 
	drop if siren=="000000000"|siren==""
	duplicates drop siren, force

	order *ape*
	sort chgapea  
	drop apeca chgapea //apenb apenc
	order *ape*

*-------------------------------------------------------------------------------
* Format data 
*-------------------------------------------------------------------------------

	rename dsd dsda
	rename ccd ccda
	rename qualif0a qualif6a
	*
	tab typcre6a
	gen typcrea="1" if typcre6a=="1"|typcre6a=="3" // rachat employeur/tiers
	replace typcrea="2" if typcre6a=="2" // heritage et reprise conjoint
	*replace typcrea="3" if typcrea=="4" // on annule transformation pp pm
	replace typcrea="4" if typcre6a=="4" // gerance
	replace typcrea="5" if typcre6a=="5" // creation nouvelle
	drop typcre6a
	tab typcrea

	save "$temp/sine_`year'", replace
	
}
*

*===============================================================================
*===============================================================================
* Append different cohorts and construct variables 
*===============================================================================
*===============================================================================
{
*** Append
	clear
	foreach year in 2006 2010 {
		append using "$temp/sine_`year'", force
	}

*** FILTERS
	* Remove firms that are inactive by the end of the survey year
	keep if etata=="A"


*** SAMPLING WEIGHTS
	gen weight 		= (poidsini)		if inlist(year,2002,2006)==1
	replace weight 	= poidsa			if inlist(year,2010,2014)==1


*** DEPARTEMENT
	gen dep		= substr(depcoma,1,2)
	replace dep	= substr(depcoma,1,3) if dep=="97"

*-------------------------------------------------------------------------------
* Entrepreneur characteristics 
*-------------------------------------------------------------------------------

*** AGE
	destring agea tagea, replace force
	replace agea=. if agea==0
	replace tagea=. if year<=1998
	gen agea24=(tagea==1|agea<=24) if (!missing(tagea)&year==2014)|(!missing(agea)&year!=2014)
	gen agea34=(tagea==2|tagea==3|(agea<=34&agea>=25)) if (!missing(tagea)&year==2014)|(!missing(agea)&year!=2014)
	gen agea44=(tagea==4|tagea==5|(agea<=44&agea>=35)) if (!missing(tagea)&year==2014)|(!missing(agea)&year!=2014)
	gen agea54=(tagea==6|tagea==7|(agea<=54&agea>=45)) if (!missing(tagea)&year==2014)|(!missing(agea)&year!=2014)
	gen agea55=(((tagea==8|tagea==9)&year==2014)|(agea>=55&year!=2014)) if (!missing(tagea)&year==2014)|(!missing(agea)&year!=2014)
	label var agea24 "24 or younger"
	label var agea34 "25-34"
	label var agea44 "35-44"
	label var agea54 "45-54"
	label var agea55 "55 or older"


***INDUSTRY EXPERIENCE
	destring compma compm0a durexpa durexp0a, replace force
	*The activity of the firm is similar to what you were doing in your previous job
	gen industry_experience = (compma == 1 & year == 2006) | (compm0a == 1 & year == 2010)
	*Same as above, and you stayed at least 3 years in your previous job
	gen industry_experience_strict = industry_experience & (((durexpa == 2 | durexpa == 3) & year == 2006) | ///
									((durexp0a == 3 | durexp0a == 4) & year == 2010))

*** GENDER
	gen male		= 1		if sexea=="1"
	replace male	= 0 	if sexea=="2"
	drop sexea

*** EDUCATION
	destring diploea, replace force
	
	gen educ="0 no" if diploea==1|diploea==2 // no qual
	replace educ="1 high school" if diploea==3|diploea==4|diploea==5 // high school
	replace educ="2 undergrad" if diploea==6|diploea==7 // undergrad
	replace educ="3 grad+" if diploea==8|diploea==9| diploea==10 // grad+
	
	gen grandeeco=(diploea==10) if !missing(diploea)
	label var grandeeco "elite school"
	
	gen educhigher=(educ=="2 undergrad" |educ=="3 grad+")
	replace educhigher=. if educ==""


*** SERIAL ENTREPRENEUR
	gen serial			= .
	lab var serial		"Serial entrepreneur (1+ firms)"
	gen serial2			= .
	lab var serial2		"Serial entrepreneur (2+ firms)"
	gen serial3			= .
	lab var serial3		"Serial entrepreneur (3+ firms)"

	replace serial		= 0		if year==2006 & inlist(nbcrea,"0")
	replace serial		= 1		if year==2006 & inlist(nbcrea,"1","2","3")
	replace serial2		= 0		if year==2006 & inlist(nbcrea,"0","1")
	replace serial2		= 1		if year==2006 & inlist(nbcrea,"2","3")
	replace serial3		= 0		if year==2006 & inlist(nbcrea,"0","1","2")
	replace serial3		= 1		if year==2006 & inlist(nbcrea,"3")

	gen _nbcrea			= real(nbcre0a) if year==2010 & creav10a=="2"	// nombre de créations précédentes si serial
	replace _nbcrea		= 0 	if year==2010 & creav10a=="1"	// si pas serial
	replace serial		= _nbcrea>=1	if year==2010 & _nbcrea<.
	replace serial2		= _nbcrea>=2	if year==2010 & _nbcrea<.
	replace serial3		= _nbcrea>=3	if year==2010 & _nbcrea<.

*** PERSONAL GOAL
	gen objectif=0 if object6a=="1" // create ones own job 
	replace objectif=1 if object6a=="2"|object6a=="3" // growing a lot 

*-------------------------------------------------------------------------------
* Current situation  
*-------------------------------------------------------------------------------
	
*** INNOVATION 
	* Innovative sector
	gen innov_sector		= .
	lab var innov_sector 	"Belong to innovative sector"

	replace innov_sector 	= 1 if year==2006 & inov=="1"
	replace innov_sector 	= 0 if year==2006 & inov=="0"

	replace innov_sector 	= 1 if year==2010 & inova=="1"
	replace innov_sector 	= 0 if year==2010 & inova=="0"
	
*===============================================================================
* Final dataset
*===============================================================================

{
	* Select and rename variables
	rename year year0_sine
	rename weight weight_sine

	* Remove a few siren duplicates
	bys siren: gen n_obs = _N
	drop if n_obs>1
	drop n_obs

	save "$output/sine_final", replace

}

*** Do some cleaning 
foreach year in 2006 2010{
	erase "$temp/sine_`year'.dta"
}

}
*

*===============================================================================
*===============================================================================
* INDUSTRY-LEVEL VARIABLES FROM SINE
*===============================================================================
*===============================================================================

*** LIST OF INNOVATIVE SECTORS
	//nb: apen is naf 2008 rev2 in SINE
	use ape* innov_sector year0_sine using "$output/sine_final", replace
	gen naf5		= apen		if year0_sine==2006
	replace naf5	= apena		if year0_sine==2010
	keep naf5 innov_sector
	duplicates drop naf5 innov_sector, force
	duplicates report naf5	// there should be no duplicates
	save "$output/innovative_naf5", replace

