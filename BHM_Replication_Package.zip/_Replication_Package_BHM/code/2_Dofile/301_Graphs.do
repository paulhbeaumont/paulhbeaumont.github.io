
*===============================================================================	
*===============================================================================
* Main Paper 
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Figure 1: Flexible Bylaws
*-------------------------------------------------------------------------------
{
	use "$output/bylaws_firm_ficus", clear	// constructed in 134_Merge_Bylaws_Ficus.do

	* Keep provisions in year 3, since they are cumulative over time (max by siren)
	* Keep if we observe the provisions at least once
	gen any_provisions = max(sample_provisions_0,sample_provisions_1, ///
	sample_provisions_2,sample_provisions_3)
	keep if any_provisions==1
	drop *_0 *_1 *_2
	* Rename provisions 
	rename *_3 *

	* We remove firms not in the Ficus sample  
	keep if sample_ficus==1

	* SAS-specific provisions
	gen any_sas_specific = max(ad_nutum,dg,free,suspension,board_total,executive_total)

	* SAS status 
	merge 1:1 siren using "$temp/dummy_sas",nogen keep(3)

*** Collapse by year and rescale %
	local varlist any_sas_specific sas_var0
	collapse (mean) `varlist', by(year0_ficus)
	rename year0_ficus year

	graph bar sas_var0 any_sas_specific, over(year, label(angle(0))) ///
		bar(1, color(navy%80)) bar(2, color(maroon%90)) ///
		bargap(20) ///
		legend(order(1 "Flexible bylaws legal form" 2 "Flexible bylaws-specific provisions") pos(6) row(1)) ///
		ylabel(0 "0%" .05 "5%" .1 "10%" .15 "15%" .2 "20%") ///
		$graph_white $leg_white
	graph export "$result/share_sas_tailored_bars.pdf", as(pdf) replace
	graph close

*** Share flexible bylaws prior to 2008 vs. 2012 
	egen msasPRE  = mean(cond(year<2008, sas_var0, .))
	egen sas2012  = mean(cond(year==2012, sas_var0, .))
	number_exporting msasPRE, name("$coeff/sasPRE") percent digits(0)
	number_exporting sas2012, name("$coeff/sas2012") percent digits(0)

*** Share flexible bylaws specific provision prior to 2008 vs. 2012 
	egen many_sas_specificPRE 	= mean(cond(year<2008, any_sas_specific, .))
	egen any_sas_specific2012	= mean(cond(year==2012, any_sas_specific, .))
	number_exporting many_sas_specificPRE, name("$coeff/taylorPRE") percent digits(0)
	number_exporting any_sas_specific2012, name("$coeff/taylor2012") percent digits(0)

}
*

*-------------------------------------------------------------------------------
* Figure 2: Balance Covariate Tests 
*-------------------------------------------------------------------------------
{
*** Prepare graph shortcut
	global bar ///
		levels(99 95) pstyle(p1)  graphregion(color(white)) plotregion(margin(medium))
	global symbolD ///
	 msymbol(D) msize(medsmall) 
	global symbolS ///
	 msymbol(S) msize(medsmall) 
	global symbolT ///
	 msymbol(T) msize(medsmall) 
	 
	global line ///
	  xline(0)  mfcolor(white) drop(_cons)
	global Navy ///
		mcolor(navy) ciopts(lwidth(1 ..) lcolor(navy*.4 navy*1))
	global Red ///
		mcolor(maroon*.7) ciopts(lwidth(1 ..) lcolor(maroon*.3 maroon*.7))
	global Green ///
		mcolor(forest_green*.5) ciopts(lwidth(1 ..) lcolor(forest_green*.2 forest_green*.5))
	global Orange ///
		mcolor(orange*.5) ciopts(lwidth(1 ..) lcolor(orange*.2 orange*.5))

*** Estimate balance covariate test 	
	eststo clear 
	
	use sas_var0 equity3${clean} Ktot3* L3${clean} Y3${clean} ${exposure} ni_at3 div_at3 ///
		net_trade_credit3* siren year  L3 Y3 Ktot2* Ktot1${clean} at3* naf* ///
		using "$output/new_inc_workingsample_th0" if year<2008, clear
	
	gen survival3 = Y3 > 0 & Y3 <.	
	gen capex3_K 	= (Ktot3 - Ktot2)/at3
	gen laborshare	= L3/Y3
	gen Y_at3 = Y3/at3
	
	merge m:1 naf5 using "$output/characteristics_naf5_all", nogen keep(1 3)  
	merge m:1 naf3 using "$output/hhi_up_down_focal",nogen keep(3)

	
	global X_list "at3 capex3_K div_at3 net_trade_credit3 Y_at3 laborshare"
	global winsor_list "at3 capex3_K div_at3 net_trade_credit3 Y_at3 laborshare"
	
*** Size and share sas
	gen size 		= ${SIZE}
	gen s_sas 		= ${s_sasDEF}


	foreach var in $winsor_list {
		winsor4 `var', method(winsor) level(1) outlier(tail) 
	}

	
	* Standardisation
	gen treated = ${exposure}
	quiet sum treated
	replace treated = treated/`r(sd)'
	
	foreach var of varlist $X_list {
		sum `var'
		global `var'SD  	=  `r(sd)'
		global `var'mean    = `r(mean)'   
	}
	foreach var of varlist $X_list {
		replace `var' 	= (`var' - $`var'mean)/$`var'SD
		gen `var'_T		= treated
	}		
		
	* No control
	local i = 0 
	foreach var in  $X_list{
		local i = `i'+1	
	    reg `var' `var'_T , cl(naf5)
		est store Loop0`i'
	}
	
	* Share existing SAS + naf2year
	local i = 0 
	foreach var in  $X_list{
		local i = `i'+1	
		reghdfe `var' `var'_T , a(naf2year c.s_sas#i.year) cl(naf5)
		est store Loop2`i'
	}	

	label var at3_T						"Assets" 
	label var capex3_K_T				"Capex"
	label var div_at3_T 				"Dividends/assets"
	label var net_trade_credit3_T		"Net trade credit"
	label var Y_at3_T 					"Revenues/assets" 
	label var laborshare_T 				"Wage bill/revenues"

	graph drop _all 
	coefplot ///
	(Loop0*, label(Unconditional) $line $Green $symbolD $bar ) ///	
	(Loop2*, label(Pre-reform flexible share + industry (2-digit) FE) $line $Navy $symbolS $bar ) ///
	, ///	
	legend(region(lcolor(none) color(white)) row(4)) ///
	graphregion(color(white))leg(cols(3) pos(6) ) ///
	xsize(5.5) xlabel(,nogrid) grid(none) 
 	graph export "$result/balance_covariate_firm.pdf", as(pdf) replace		
	graph close
	
}
*

*-------------------------------------------------------------------------------
* Figure 3: Effect of the Reform on Flexible Bylaws Adoption	
*-------------------------------------------------------------------------------
{
	use $fe_reg_list $cluster siren year  ///
		sample sas_var0 Z ///
		using "$output/new_inc_workingsample_th0" if sample =="new", clear

	local i = 0
	forvalues spe = 1/$fe_nspec {
		local i = `i'+1
		evstudydd sas_var0 year,treated(Z) shocktime(2007) period(2 4) ///
			fe(${fe_spec`spe'}) cl($cluster) name("$gcoeff/sas_evstudy`i'")
	}
	
*** Output figure 
	clear
	forval i = 1 /3{
		append using "$gcoeff/sas_evstudy`i'"	
		Coeffyear `i' 2007
	}
	graph twoway ///
	(rcap B1inf B1sup t1, $se $light_blue) ///
	(scatter B1 t1, $beta_triangle $blue) ///	
	(rcap B2inf B2sup t2, $se $light_green) ///
	(scatter B2 t2, $beta_square $green) ///	
	(rcap B3inf B3sup t3, $se $light_red) ///
	(scatter B3 t3, $beta_diamond $redF) ///				
	$graph ylabel(,nogrid angle(0)) ///
	$graph_white $leg_white  xsize(8) ///
	leg(order(2 "Ind2xYear" 4 "+ Pre-reform flexible sharexYear" 6 "+ CountyxYear" )  cols(3))
	graph export "$result/sas_evstudy_all.pdf", as(pdf) replace	
	graph close

}
*

*-------------------------------------------------------------------------------
* Figure 4: Effect of the Reform on Capital 
*-------------------------------------------------------------------------------
{
	use $fe_reg_list $cluster Ktot3${clean} ${SIZE} Z ///
		using "$output/new_inc_workingsample_th0" , clear

	local i = 0
	forvalues spe = 1/$fe_nspec {
		local i = `i'+1
		evstudydd Ktot3${clean} year,treated(Z) shocktime(2007) period(2 4) ///
			fe(${fe_spec`spe'}) cl($cluster) name("$gcoeff/K_evstudy`i'")
	}	
	
*** Output figure 
	clear
	forval i = 1/$fe_nspec {
		append using "$gcoeff/K_evstudy`i'"	
		Coeffyear `i' 2007
	}
	graph twoway ///
	(rcap B1inf B1sup t1, $se $light_blue) ///
	(scatter B1 t1, $beta_triangle $blue) ///	
	(rcap B2inf B2sup t2, $se $light_green) ///
	(scatter B2 t2, $beta_square $green) ///	
	(rcap B3inf B3sup t3, $se $light_red) ///
	(scatter B3 t3, $beta_diamond $redF) ///						
	$graph ylabel(,nogrid angle(0)) ///
	$graph_white $leg_white  xsize(8) ///
	leg(order(2 "Ind2xYear" 4 "+ Pre-reform flexible sharexYear" 6 "+ CountyxYear" 8)  cols(3))
	graph export "$result/K_evstudy_all.pdf", as(pdf) replace	
	graph close
	
}
*
