




*** ESTTAB COMMAND 

	global tableEnvironment ///
		replace cells(b(fmt(%9.2g) star) se(fmt(%9.2g) par))  ///
		starlevels(* .1 ** .05 *** .01) ///
		varwidth(50) nolines  posthead(\midrule) label	///
		fragment mlabels(none) collabels(none) booktab   ///		
		stats(N_true, fmt(%9.0fc) label("\vspace{0.1em}Observations")) nonotes

		
*** True nb of obs with regdfe
global trueobs ///
	estadd scalar N_true = e(N) + e(num_singletons)

*** Compute mean of RHS AND LHS VAR	
capture program drop meanLHS
	program define meanLHS
	qui sum `1' if year<=2012 & treated==1
	local mean = r(mean)
	estadd scalar MeanY = `mean'
end

*** DID GRAPH SETTINGS	
	global graph ///
		, yline(0, lcolor(gs4) lpattern(dash)) ///
		xline(2007, lcolor(gs4) lpattern(dash)) ///
		xscale(titlegap(3)) xtitle("") ytitle(" ") ///
		ylabel(,nogrid angle(0)) ///
		xlabel(,nogrid labsize(small)) ///
		graphregion(fcolor(white)) graphregion(color(white))  bgcolor(white) ///
		leg(pos(6))

		
	// Graph environment: white
	global graph_white ///
		graphregion(color(white))  bgcolor(white) ylabel( ,nogrid angle(0))

	
	// Legend environment
	global leg_white ///
	graphregion(color(white)) legend(region(lcolor(white) lwidth(vvthick)) symxsize(9) forcesize)  	
	
	global leg_position ///
	leg(row(2) pos(6))
		
	// s.e.	formatting
	global se ///
		lpattern(longdash) lwidth(thin)	
		
	// Point estimates formatting
	global beta ///
		msymbol(diamond) msize(medium) mlwidth(medium) ///
		connect(l) clpattern(longdash) sort 
		
	global beta_diamond ///
		msymbol(diamond) msize(medlarge) mlwidth(medium)
	
	global beta_triangle ///
		msymbol(T) msize(medlarge) mlwidth(medium)
	
	global beta_square ///
		msymbol(S) msize(medlarge) mlwidth(medium)
		
	global beta_round ///
		msymbol(O) msize(medlarge) mlwidth(medium)

	// Specify the set of colors for point estimates if filled
	global redF ///
		mlcolor(maroon%90) lcolor(maroon%90) mfcolor(red*.25)
	global orangeF ///
		lcolor(orange*1.25) mlcolor(orange*1.25) mfcolor(orange*.25)		
	global blueF ///
		lcolor(navy%80) mlcolor(navy%80) mfcolor(midblue*.25)
	global greenF ///
		lcolor(forest_green%80) mlcolor(forest_green%80) mfcolor(forest_green*.25)
	global purpleF ///
		lcolor(purple%60) mlcolor(purple%60) mfcolor(purple*.25)
	global brownF ///
		lcolor(brown%60) mlcolor(brown%60) mfcolor(brown*.25)		
	global pinkF ///
		lcolor(magenta%60) mlcolor(magenta%60) mfcolor(magenta*.25)		
	
	
	
	
	// Set of colors for point estimates (empty)
	global red ///
		mlcolor(maroon%90) lcolor(maroon%90) mfcolor(white)
	global blue ///
		lcolor(navy%80) mlcolor(navy%80) mfcolor(white)	
	global orange ///
		lcolor(orange*1.25) mlcolor(orange*1.25) mfcolor(white)
	global green ///
		lcolor(forest_green%80) mlcolor(forest_green%80) mfcolor(white)
	global purple ///
		lcolor(purple%60) mlcolor(purple%80) mfcolor(white)
	global yellow /// 
		lcolor(sand%60) mlcolor(sand%60) mfcolor(white)
	global brown ///
		lcolor(brown%60) mlcolor(brown%60) mfcolor(white)
	global pink ///
		lcolor(magenta%60) mlcolor(magenta%60) mfcolor(white)
	global cyan ///
		lcolor(cyan%60) mlcolor(cyan%60) mfcolor(white)
	global ebg ///
		lcolor(ebg) mlcolor(ebg) mfcolor(white)
	global black ///
		lcolor(black%60) mlcolor(black%60) mfcolor(white)		
	global grey ///
		lcolor(gs8) mlcolor(gs8) mfcolor(white)					
	global white ///
		lcolor(gs12%0) mlcolor(gs12%0) mfcolor(white%0)				
	global teal ///
		lcolor(teal%90) mlcolor(teal%90) mfcolor(white)

	// Specify the set of colors for standard errors 	
	global light_grey ///
		lcolor(gs10) mlcolor(gs10)					
	global light_red ///
		mlcolor(maroon%50) lcolor(maroon%50)
	global light_blue ///
		lcolor(navy%50) mlcolor(navy%50)	
	global light_orange ///
		lcolor(orange*1.25%50) mlcolor(orange*1.25%50)
	global light_green ///
		lcolor(forest_green%50) mlcolor(forest_green%50)
	global light_purple ///
		lcolor(purple%50) mlcolor(purple%50)
	global light_yellow ///
		lcolor(sand%50) mlcolor(sand%50)
	global light_black ///
		lcolor(black%50) mlcolor(black%50)
	global light_pink ///
		lcolor(magenta%50) mlcolor(magenta%50)	
	global light_teal ///
		lcolor(teal%50) mlcolor(teal%50)
	global light_ebg ///
		lcolor(ebg%50) mlcolor(ebg%50)
	global light_brown ///
		lcolor(brown%50) mlcolor(brown%50)

	
************************************************
************		PROGRAMS		************
************************************************
{

*** Define lhs function 
	capture program drop lhs
	program define lhs
		gen `2'=log(`1'+(`1'^2+1)^(1/2))
	end
	
}
*
************************************************
************		D-i-D Graph		************
************************************************
{

/*
	Automatize some elements of graph construction post event study that are always 
	the same
*/
capture program drop Coeff
program define Coeff

	#d;
		cap rename (B SE) (B`1' SE`1')			;
		cap gen B`1'sup	= B`1'+1.96*SE`1'		;
		cap gen B`1'inf	= B`1'-1.96*SE`1'		;	
		cap gen t`1' 	= (time)+(`1'-1)*.10	;	
	#d cr
end	

capture program drop Coeffyear
program define Coeffyear
	#d;
		cap rename (B SE) (B`1' SE`1')			;
		cap gen B`1'sup	= B`1'+1.96*SE`1'		;
		cap gen B`1'inf	= B`1'-1.96*SE`1'		;	
		cap gen t`1' 	= (time+`2')+(`1'-1)*.10	;	
	#d cr
end	


}
*














