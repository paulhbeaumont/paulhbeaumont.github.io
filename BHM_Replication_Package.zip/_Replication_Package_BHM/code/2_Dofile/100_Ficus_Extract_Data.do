


*===============================================================================
* OPEN FICUS - FARE, EXTRACT THE RELEVANT VARIABLES AND DO SOME RENAMING
*===============================================================================
{

*-------------------------------------------------------------------------------
* Extra data coming from raw tax files 
*-------------------------------------------------------------------------------	


/*
	Note: when we sum different components, we intentionally use rowtotal 
	so that we treat missing components as 0
*/	
	
	local year = 2008
	use "$source_conf/ficusfare/liasse_`year'" , clear 
	
	* Careful, in the raw liasse, zeros are actually missing 
	quiet foreach var in co da db dd de df dg dh dc dk fa fd fg bx bv{
		recode `var' . = 0 
	}
	gen equity 	= (da + db) 
	gen autcapi = dc + dd + de + df + dg + dh + dk
	gen catotal = fa + fd + fg
	* drop missing siren
	drop if inlist(siren,"",".","0","000000000")
	* Duplicates
	gsort siren catotal 
	by siren: keep if _n==_N	
			
	gen avance_supplier	= bx
	gen credit_supplier	= bv	
	gen at 		= co 
	
	* All units are in euro, while they are in thousands in FARE 
	foreach var in equity autcapi avance_supplier credit_supplier at{
		replace `var' = `var'/1000
	}
	gen year = `year'
	keep siren year equity autcapi avance_supplier credit_supplier at
	save "$temp/liasse_`year'", replace


*-------------------------------------------------------------------------------
* FICUS 
*-------------------------------------------------------------------------------	
 
	* list of variables selected in ficus
	global Xficus dep com ape cj ctdx siren datcr capisoc autcapi typimpo ///
	catotal tactibr effsalm vabcf ///
	dividen resubic resubnc saltrai avanver creacli autcrea ///
	avancou detfour autdett empdett ///
	immocor immoinc invcorp dividen charsoc ebe ///
	subvinv autfond proviri tactint disponi valmobi
	
forval yr = 1994/2007{		
	display in red "Ficus `yr'"
	
	quiet {
		use $Xficus ///
			using "$source_conf/ficusfare/ficus_`yr'" ,clear
		
		** SIREN 
		* drop missing siren
		drop if inlist(siren,"",".","0","000000000")
		* Duplicates
		gsort siren catotal 
		by siren: keep if _n==_N	
		
		*DATE, DATE CREATION
		gen year = `yr'
		gen yrcrea = substr(datcr,1,4)
		destring yrcrea,force replace

		*VARIABLES
		gen ca 		= catotal 
		gen emp		= effsalm
		gen va 		= vabcf
		gen div		= dividen
		gen ni		= resubic 
		replace ni 	= resubnc if ni==.
		gen wages 	= saltrai
		
		gen at		= tactibr	
		gen equity	= capisoc	
		gen debt	= empdett
		
		gen avance_customer	= avanver //  Avances/acomptes sur commandes
		gen credit_customer	= creacli  // Cr{ances : clients et comptes rattach{s ÊBXÝ
		
		gen avance_supplier	= avancou //  Avances et acomptes re\us sur commandes en cours
		gen credit_supplier	= detfour //  Dettes fournisseurs et comptes rattach{s ÊDXÝ
		gen ocli			= autdett //  Les autres dettes ÊDY+DZ+EAÝ
			
		gegen cash			= rowtotal(disponi valmobi)
			
		// Geography 
		* department
		* Adjust the department code for corsica (use 20)
		replace dep = substr(dep,1,2)
		replace dep = "20" if dep=="2A" | dep=="2B"
		
		cap tostring com,replace 
		cap replace com = "" if com == "."
		cap replace com = substr("00"+com,-3,.)
		
		* create code communes
		gen commune = dep+com
		destring dep commune,replace
							
		keep siren year ape cj dep year-commune ///
			immocor immoinc autcapi charsoc ebe subvinv autfond ///
			proviri datcr

		compress
		save "$temp/ficus_fare_nofilter_`yr'", replace	
	}
}
*
		
*** FARE 2008 
{
	global Xfare08 ///
		siren* cj* ape* com* dep* datcr* ///
		catotal* saltrai* vabcf* resulta* dividen* dotamor* effsalm* charsoc* ///
		immoinc* immocor* ebe*
	
	use $Xfare08 using "$source_conf/ficusfare/fare_2008"  , clear 
	
	foreach var in siren com ape cj catotal saltrai ebe dividen effsalm dep ///
	charsoc datcr dotamor immoinc immocor  ///
	vabcf resulta { 
		gen `var' = `var'_08
	}
	
	** SIREN 
	* drop missing siren
	drop if inlist(siren,"",".","0","000000000")
	* Duplicates
	gsort siren catotal 
	by siren: keep if _n==_N	

	*DATE, DATE CREATION
	gen yrcrea = substr(datcr,1,4)
	destring yrcrea,force replace
	gen year = 2008
	
	// Some renaming 
	gen ca 			= catotal 
	gen wages		= saltrai 
	gen va			= vabcf // VA au coit des facteurs 
	gen ni			= resulta // R{sultat de l'exercice 
	gen div			= dividen
	gen emp			= effsalm	

	drop *_08 
	
	// Geography 
	* department
	replace dep = substr(dep,1,2) 
	* Adjust the department code for corsica (use 20)
	replace dep = "20" if dep=="2A" | dep=="2B"
	destring dep,replace 
	
	* create code communes
	gen commune = substr(com,-3,.)
	destring commune,replace
	replace commune = dep*1000+commune
	drop com
		
	** Bring raw liasse fiscale for missing variables 
	merge 1:1 siren using "$temp/liasse_2008",nogen keep(1 3)
	
	keep siren year ape cj yrcrea-at ///
		immocor immoinc charsoc ebe datcr

	compress
	save "$temp/ficus_fare_nofilter_2008", replace
}

*** FARE 2009-2017
	global Xfare ///
		siren depcom stat_cj ape_diff ent_cre_daaaammjj ///
		r100 r004 ///
		redi_r401 redi_r402 redi_r403 redi_r216 redi_r217 redi_r005 redi_e200 ///
		b171 b172 b173 b181 b182 b302 b303 b320 b341 b342 b348 ///
		immo_corp immo_inc b190 b604 b100 b330 capisoc  ///
		
forval yr = 2009/2017{
	display in red "fare `yr'"
	
	quiet{
		use $Xfare using "$source_conf/ficusfare/fare_`yr'" ,clear

		gegen ca = rowtotal(redi_r401 redi_r402 redi_r403)
		
		** SIREN 
		* drop missing siren
		drop if inlist(siren,"",".","0","000000000")
		* Duplicates
		gsort siren ca 
		by siren: keep if _n==_N	

		rename ape_diff ape 
		rename stat_cj cj 	
		
		*DATE, DATE CREATION
		gen yrcrea = substr(ent_cre_daaaammjj,1,4)
		destring yrcrea,force replace
		rename ent_cre_daaaammjj datcr
		gen year = `yr'	
		
		*VARIABLES
		// Some renaming 
		gen wages			= redi_r216 // charges dexploitation: salaires et traitement 
		gen charsoc			= redi_r217 // Charges d'exploitation : Charges sociales (FZ)
		gen va				= r004 // VA au coit des facteurs 
		gen ebe  			= redi_r005 // or according to Paul vaj-redi_r215-redi_r216-redi_r217+redi_r313
		gen avance_customer	= b171  //  Avances et acomptes vers{s sur commandes
		gen credit_customer	= b172  // Cr{ances : clients et comptes rattach{s ÊBXÝ
		gen avance_supplier	= b341 //  Avances et acomptes re\us sur commandes en cours
		gen credit_supplier	= b342 //  Dettes fournisseurs et comptes rattach{s ÊDXÝ
		gen ocli			= b348 //  Les autres dettes ÊDY+DZ+EAÝ

		gen immocor 		= immo_corp
		gen immoinc			= immo_inc

		gen div				= b604
		gen at				= b100
		gen debt			= b330
		gen emp				= redi_e200
		gegen cash			= rowtotal(b181 b182)
		gen ni				= r100 // resultat comptable  OR b319 "R{sultat de l'exercice (b{n{fice ou perte) 

		gen equity			= capisoc	
		gen subvinv 		= b320
		gen autfond 		= b302
		gen proviri 		= b303
		
		// Geography 
		* department
		gen dep = substr(depcom,1,2) 
		
		* Adjust the department code for corsica (use 20)
		replace dep = "20" if dep=="2A" | dep=="2B"
		destring dep,replace 
		
		* create code communes
		gen commune = substr(depcom,-3,.)
		destring commune,replace
		replace commune = dep*1000+commune
		
		* SELECTION
		keep cj siren year ape ca - commune datcr

		compress
		save "$temp/ficus_fare_nofilter_`yr'", replace
	}
}	
*
	
*
}
*

*===============================================================================
* Extract first year in Ficus-Fare 
*===============================================================================

clear 
forval yr = 1994/2017{	
	append using "$temp/ficus_fare_nofilter_`yr'", keep(siren year)
}
gcollapse(min) fyear_ff=year,by(siren)
label var fyear_ff "First year in ficus-fare"
compress
save "$temp/ficus_fare_fyear",replace 







	
