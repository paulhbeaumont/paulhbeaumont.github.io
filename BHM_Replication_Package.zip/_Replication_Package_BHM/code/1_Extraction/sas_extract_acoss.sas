



%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir= C:\Users\Public\Documents\Raw_dta_confidential\acoss;



;/* Macro to transform upper case in lower case (important for dta export  */
%macro lower_vars(lib=WORK , data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into : renlist separated by ' '
		from dictionary.columns 
		where libname = upcase("&lib")
		and memname = upcase("&data")
		and name ne lowcase(name);
	quit;
	%if %length(&renlist) %then %do;
	proc datasets lib=&lib nolist;
		modify &data;
		rename &renlist;
	quit;
	%end;
%mend;



;/* ACOSS: Open sas and save as .dta  */
%macro acoss(listyears,outdir);
	%local i year yr2;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);
	
		data _null_;
		put "NOTE: Year=&year YR2=&yr2";
		run;

		libname acoss&yr2 "&inpath.\Base non salari�s_Base non salari�s_&year";


		/* Load raw data */
		data mydata;
		set acoss&yr2..bns_acoss_&year ;
		run;
		
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\acoss_&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

%let i 	=%eval(&i+1);
%end;	
%mend;

%let listyears =  2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 ;
%acoss(&listyears,&outdir);

