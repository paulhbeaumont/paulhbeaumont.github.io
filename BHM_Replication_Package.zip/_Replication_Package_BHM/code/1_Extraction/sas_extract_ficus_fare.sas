





%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir= C:\Users\Public\Documents\Raw_dta_confidential\ficusfare;



;/* Macro to transform upper case in lower case (important for dta export  */
%macro lower_vars(lib=WORK , data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into : renlist separated by ' '
		from dictionary.columns 
		where libname = upcase("&lib")
		and memname = upcase("&data")
		and name ne lowcase(name);
	quit;
	%if %length(&renlist) %then %do;
	proc datasets lib=&lib nolist;
		modify &data;
		rename &renlist;
	quit;
	%end;
%mend;


;/* Ficus  */
%macro ficus(listyears,outdir);
	%local i year yr2;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);
	
		data _null_;
		put "NOTE: Year=&year YR2=&yr2";
		run;

		/* Handle the fact that path changes over years */
		%if (&year >= 1994 & &year<=2000) %then %do;
			libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers en euros";
		%end;
		%else %if (&year >= 2001 & &year<=2004) %then %do;
			libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit s l gales";
		%end;
		%else %if (&year >= 2005 & &year<=2007) %then %do;
			libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit s consolid es et les unit s l gales hors contours des profilages";
		%end;

		/* Load raw data */
		data mydata;
		set ficus&yr2..apu ficus&yr2..fin ficus&yr2..tab ;
		run;
		
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\ficus_&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

%let i 	=%eval(&i+1);
%end;	
%mend;

%let listyears = 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 ;
%ficus(&listyears,&outdir);


;/* Fare  */
%macro fare(listyears,outdir);
	%local i year;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	libname fare&year "&inpath.\Statistique annuelle d'entreprise_FARE_&year";
	%let lib = fare&year;
	
	/* Handle the fact that raw data has different names over years */
	%if (&year >= 2008 & &year<=2009) %then %do;
		%let mem =  tab  ;
	%end;
	%else %if (&year >= 2010 & &year<=2011) %then %do;
		%let mem =  fare&year ;
	%end;

	%else %if (&year = 2012) %then %do;
		%let mem =  fare&year._meth&year ;
	%end;
	%else %do;
		%let mem = fare&year.meth&year;
	%end;

	/* load raw data */
	data mydata;
		set &lib..&mem ;
	run;

	/* Macro to rename upper case to lower case */

	%lower_vars(lib=work, data=mydata);

	/* Export in dta */ 
	proc export data=mydata outfile="&outdir.\fare_&year..dta" replace;
	run;

	/* Clean memory */
	proc datasets lib=work nolist;
		delete mydata collapsed;
	quit;

	%let i 	=%eval(&i+1);
	%end;	
%mend;

%let listyears = 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017;
%fare(&listyears,&outdir);
