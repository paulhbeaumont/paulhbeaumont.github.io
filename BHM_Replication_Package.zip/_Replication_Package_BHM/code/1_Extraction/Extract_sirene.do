
*===============================================================================
*===============================================================================
* 	FILE CREATION (SIRENE)	 
*===============================================================================
*===============================================================================

{
		
		
forval yr = 1987/2017 {
    * Set directory path
    local path "$rawdatadir/REE_Créations Entreprises_`yr'"
    if `yr' >= 2012 local path "`path'/Versions/V1"
    cd "`path'"
    
    * Import appropriate file
    local fname "france`=cond(`yr'>=2016,"`yr'","")'.sas7bdat"
    import sas "`fname'", clear
    rename *, lower
    
    * Rename for years <= 2006
    if `yr' <= 2006 {
        rename dmaj ori_demo_date
    }
    
    * Handle auto-entrepreneurs (2009-2011 only)
    if inrange(`yr',2009,2011) {
        drop if auto_entrepreneur == "1"
    }
    
    cap gen year = `yr'
    
    * Keep relevant variables
    if `yr' <= 2008 {
        keep ori_demo_date apen cj year siren
    }
    else {
        keep ori_demo_date apen cj year siren auto_entrepreneur
    }
    
    * Save
	save "$temp/SIRENE_creation_`yr'",replace
}


*-------------------------------------------------------------------------------
* Append and take first time we see a siren when multiple 
*-------------------------------------------------------------------------------

	clear
	forvalues yr =1987(1)2017{
		append using "$temp/SIRENE_creation_`yr'"
	}

*** Remove possible duplicates within year 
	bys siren year: gen dup = _n 
	drop if dup >1
	drop dup
	* Across years, keep the first year 
	sort siren year 
	by siren: keep if _n==1

	rename year yrcrea_sirene
	save "$output/crea_all",replace
	
*-------------------------------------------------------------------------------
* Append and take last time we see a siren when multiple 
*-------------------------------------------------------------------------------

	clear
	forvalues yr =1987(1)2017{
		append using "$temp/SIRENE_creation_`yr'"
	}
	bys siren year: gen dup = _n 
	drop if dup >1
	drop dup
	gsort siren year 
	by siren: keep if _n==_N

	rename year yrcrea_sireneLast
	save "$output/crea_all_last",replace
	
	
*** Clean (preserve 2009 for control later)
	forvalues yr =1987(1)2017{
		if `yr'!=2009{
			erase "$temp/SIRENE_creation_`yr'.dta"
		}
	}	
	
	
}
*	

*===============================================================================
*===============================================================================
*	FILE STOCK (SIRENE)	 
*===============================================================================
*===============================================================================

{
*** Extract each year
	local fyear ${fyear_all}
	local lyear ${lyear_all}
	
	forval yr = `fyear'/`lyear'{
		* Set directory path
		local path "${rawdatadir}/REE_Stocks Entreprises_`yr'"
		if `yr' >= 2014 local path "`path'/Versions/V1"
		cd "`path'"
				
		* Set filename
		if `yr' <= 2009 {
			local X = `yr' - 2000
			local fname "STENT0`X'.sas7bdat"
		}
		else if `yr' <= 2015 {
			local X = `yr' - 2000
			local fname "STENT`X'.sas7bdat"
		}
		else {
			local X = 31120000 + (`yr') -1 	// EDITED BY JOHAN 24 MARCH 2026: Added -1 to match file name
			local fname "STENT_`X'.sas7bdat"
		}
		
		import sas "`fname'", clear
		rename *, lower
		gen year = `yr'
		keep siren year depcom_siege
		tempfile SIRENE_stock_`yr'
		save `SIRENE_stock_`yr''
	}

*** Append sirene stock and get geographic info 	
	clear 
	forval yr = `fyear'/`lyear'{
		append using `SIRENE_stock_`yr'',keep(siren year depcom_siege )
	}
	gduplicates drop siren year, force // 3 true duplicates in 2008 
	compress 
	save "$output/stocks_geography",replace  

}

