














%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir= C:\Users\Public\Documents\Raw_dta_confidential\ficusfare;



;/* Macro to transform upper case in lower case (important for dta export  */
%macro lower_vars(lib=WORK , data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into : renlist separated by ' '
		from dictionary.columns 
		where libname = upcase("&lib")
		and memname = upcase("&data")
		and name ne lowcase(name);
	quit;
	%if %length(&renlist) %then %do;
	proc datasets lib=&lib nolist;
		modify &data;
		rename &renlist;
	quit;
	%end;
%mend;


;/* Working path for ficus 1994-2000  */
/*
%macro ficus_libname9400(listyears);
	%local i year yr2;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);
	libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers en euros";
%let i 	=%eval(&i+1);
%end;	
%mend;
%let listyears = 1994 1995 1996 1997 1998 1999 2000 ; /**/
*%ficus_libname9400(&listyears);
*/

/*
libname ficus01 "&inpath.\Statistique annuelle d'entreprise_FICUS_2001\Fichiers avec les unit s l gales";
libname ficus02 "&inpath.\Statistique annuelle d'entreprise_FICUS_2002\Fichiers avec les unit s l gales";
libname ficus03 "&inpath.\Statistique annuelle d'entreprise_FICUS_2003\Fichiers avec les unit s l gales";
libname ficus04 "&inpath.\Statistique annuelle d'entreprise_FICUS_2004\Fichiers avec les unit s l gales";
libname ficus05 "&inpath.\Statistique annuelle d'entreprise_FICUS_2005\Fichiers avec les unit s consolid es et les unit s l gales hors contours des profilages" ; 
libname ficus06 "&inpath.\Statistique annuelle d'entreprise_FICUS_2006\Fichiers avec les unit s consolid es et les unit s l gales hors contours des profilages" ; 
libname ficus07 "&inpath.\Statistique annuelle d'entreprise_FICUS_2007\Fichiers avec les unit s consolid es et les unit s l gales hors contours des profilages" ; 


*/

;/* Ficus  */
%macro ficus(listyears,outdir);
	%local i year yr2;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);
	
		data _null_;
		put "NOTE: Year=&year YR2=&yr2";
		run;

		/* Handle the fact that path changes over years */
		%if (&year >= 1994 & &year<=2000) %then %do;
			libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers en euros";
		%end;
		%else %if (&year >= 2001 & &year<=2004) %then %do;
			libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit s l gales";
		%end;
		%else %if (&year >= 2005 & &year<=2007) %then %do;
			libname ficus&yr2 "&inpath.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit s consolid es et les unit s l gales hors contours des profilages";
		%end;

		/* Load raw data */
		data mydata;
		set ficus&yr2..apu ficus&yr2..fin ficus&yr2..tab ;
		run;
		
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\ficus_&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

%let i 	=%eval(&i+1);
%end;	
%mend;

%let listyears = 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 ;
%ficus(&listyears,&outdir);


;/* Fare  */
%macro fare(listyears,outdir);
	%local i year;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	libname fare&year "&inpath.\Statistique annuelle d'entreprise_FARE_&year";
	%let lib = fare&year;
	
	/* Handle the fact that raw data has different names over years */
	%if (&year >= 2008 & &year<=2009) %then %do;
		%let mem =  tab  ;
	%end;
	%else %if (&year >= 2010 & &year<=2011) %then %do;
		%let mem =  fare&year ;
	%end;

	%else %if (&year = 2012) %then %do;
		%let mem =  fare&year._meth&year ;
	%end;
	%else %do;
		%let mem = fare&year.meth&year;
	%end;

	/* load raw data */
	data mydata;
		set &lib..&mem ;
	run;

	/* Macro to rename upper case to lower case */

	%lower_vars(lib=work, data=mydata);

	/* Export in dta */ 
	proc export data=mydata outfile="&outdir.\fare_&year..dta" replace;
	run;

	/* Clean memory */
	proc datasets lib=work nolist;
		delete mydata collapsed;
	quit;

	%let i 	=%eval(&i+1);
	%end;	
%mend;

%let listyears = 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017;
%fare(&listyears,&outdir);













%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir= C:\Users\Public\Documents\dividend\_2025\_replicationPackage\data\source\Raw_dta_confidential\dads_postes;


;/* Macro to transform upper case in lower case (important for dta export  */
%macro lower_vars(lib=WORK , data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into : renlist separated by ' '
		from dictionary.columns 
		where libname = upcase("&lib")
		  and memname = upcase("&data")
		  and name ne lowcase(name);
	quit;
	%if %length(%superq(renlist)) %then %do;
	proc datasets lib=&lib nolist;
		modify &data;
		rename &renlist;
	quit;
	%end;
	%else %put NOTE: all variables already in lowercase;
%mend;


; /* Compute macro for all cases outside idf and including idf for 09-10*/;
%macro extract_dads0817(listyears,listreg,outdir);
	%local i j year yr2 reg;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);

	%let j = 1;
	%do %while(%length(%scan(&listreg,&j)));
		%let reg	=%scan(&listreg, &j);

		%put NOTE: YEAR=&year YR2=&yr2 REG=&reg;

		/* 008: No difference in names for the raw data  */
		%if (&year=2008) %then %do;
			libname dads&yr2 "&inpath.\DADS_DADS Postes_&year";
			%let mem =  Post&reg.&yr2  ;
		%end;

		/* 09-13: name change */
		%else %if (&year>=2009 & &year<=2013) %then %do;
			libname dads&yr2 "\\casd.fr\casdfs\Projets\FISCENT\Data\DADS_DADS Postes_&year";
			%let mem =  Post&reg  ;
		%end;
		/* 14 onward: path + name changes also outside idf */
		%else %if (&year>=2014) %then %do;
			libname dads&yr2 "\\casd.fr\casdfs\Projets\FISCENT\Data\DADS_DADS Postes_&year\R gions";
			%let mem =  Post&reg  ;
		%end;		

		/* load raw data */
		data mydata;
			set dads&yr2..&mem (keep = siren pcs s_brut);
		run;

		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\dads_postes_&year._&reg..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

		%let j 		=%eval(&j+1);
		%end;
%let i 	=%eval(&i+1);
%end;	
%mend;



; /* Compute macro special for idf for 12-13*/;
%macro extract_dadsidf1213(listyears,listreg,outdir);
	%local i j year yr2 reg;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);

	%let j = 1;
	%do %while(%length(%scan(&listreg,&j)));
		%let reg	=%scan(&listreg, &j);

		libname idf&yr2 "&inpath.\DADS_DADS Postes_&year\Ile de France";

		%let mem =  Post&reg  ;

		/* load raw data */
		data mydata;
			set idf&yr2..&mem (keep = siren );
		run;

		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\dads_postes_&year._&reg.idf.dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata;
		quit;
	  
		%let j 		=%eval(&j+1);
		%end;
%let i 	=%eval(&i+1);
%end;	
%mend;


; /* Compute macro special for idf for 11-onwards*/;
%macro extract_dadsidf1417(listyears,listreg,outdir);
	%local i j year yr2 reg;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);

	%let j = 1;
	%do %while(%length(%scan(&listreg,&j)));
		%let reg	=%scan(&listreg, &j);

		libname idf&yr2 "&inpath.\DADS_DADS Postes_&year\D partements";

		%let mem =  Post&reg  ;

		/* load raw data */
		data mydata;
			set idf&yr2..&mem (keep = siren );
		run;
 
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\dads_postes_&year._&reg.idf.dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata;
		quit;

		%let j 		=%eval(&j+1);
		%end;
%let i 	=%eval(&i+1);
%end;	
%mend;

/*################################################################### */
/*RUN MACRO   */
/*################################################################### */


/* Run macro: 2008: old regions*/;
%let listyears = 2008 ;
%let listreg = 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 ; /**/
%extract_dads0817(&listyears, &listreg,&outdir);

/* Run macro: 2009-2013: old regions except idf and region 82*/;
%let listyears = 2009 2010 2011 2012 2013 ; /*2009 2010 2011 2012 2013*/
%let listreg = 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 83 91 93 94 97 99; /**/
%extract_dads0817(&listyears, &listreg,&outdir);

/* Run macro: 2010: region 82 is split between 82a and 82b*/;
%let listyears = 2010 ; 
%let listreg = 82a 82b; 
%extract_dads0817(&listyears, &listreg,&outdir);

/* Run macro: 2009 and 2011-2013: region 82 is normal*/;
%let listyears = 2009 2011 2012 2013 ; 
%let listreg = 82; 
%extract_dads0817(&listyears, &listreg,&outdir);

/* Run macro: 2014-onwards: new regions except idf*/;
%let listyears = 2014 2015 2016 2017;
%let listreg = 24 27 28 32 44 52 53 75 76 84 93 94 97 99; /**/
%extract_dads0817(&listyears, &listreg,&outdir);

/*################################################################### */
/*MACRO FOR ILE-DE-FRANCE  */
/*################################################################### */

/* Run macro: 2009-2010: idf format aa bb cc dd*/;
%let listyears = 2009 2010  ;
%let listreg = 11aa 11bb 11cc 11dd; /*  */
%extract_dads0817(&listyears, &listreg,&outdir);


/* Run macro: 2011: idf format is normal*/;
%let listyears = 2011  ;
%let listreg = 11 ; /*  */
%extract_dads0817(&listyears, &listreg,&outdir);

/* Run macro: 2012-2013: idf with dep code so output is saved with "idf" at the end*/;
%let listyears = 2012 2013 ;/*  */
%let listreg =  75 77 78 91 92 93 94 95  ; /* */
%extract_dadsidf1213(&listyears, &listreg,&outdir);


/* Run macro: 2014-2017: idf with dep code so output is saved with "idf" at the end*/;
%let listyears =  2014 2015 2016 2017  ;/* 2014 2015 2016 2017   */
%let listreg =  75 77 78 91 92 93 94 95 ; /* */
%extract_dadsidf1417(&listyears, &listreg,&outdir);


























%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir= C:\Users\Public\Documents\dividend\_2025\_replicationPackage\data\source\Raw_dta_confidential\acoss;



;/* Macro to transform upper case in lower case (important for dta export  */
%macro lower_vars(lib=WORK , data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into : renlist separated by ' '
		from dictionary.columns 
		where libname = upcase("&lib")
		and memname = upcase("&data")
		and name ne lowcase(name);
	quit;
	%if %length(&renlist) %then %do;
	proc datasets lib=&lib nolist;
		modify &data;
		rename &renlist;
	quit;
	%end;
%mend;



;/* ACOSS: Open sas and save as .dta  */
%macro acoss(listyears,outdir);
	%local i year yr2;
	%let i = 1;
	%do %while(%length(%scan(&listyears,&i)));
	%let year	=%scan(&listyears, &i);
	%let yr2	=%substr(&year, 3,2);
	
		data _null_;
		put "NOTE: Year=&year YR2=&yr2";
		run;

		libname acoss&yr2 "&inpath.\Base non salari s_Base non salari s_&year";


		/* Load raw data */
		data mydata;
		set acoss&yr2..bns_acoss_&year ;
		run;
		
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\acoss_&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

%let i 	=%eval(&i+1);
%end;	
%mend;

%let listyears =  2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 ;
%acoss(&listyears,&outdir);

