
*** Ficus 	
forval yr = 1994/2007{		
	* Append yearly files
	use "$source_conf/ficusfare/ficus`yr'tab", clear
	append using "$source_conf/ficusfare/ficus`yr'fin"
	append using "$source_conf/ficusfare/ficus`yr'apu" 
	
	save "$source_conf/ficusfare/ficus_`yr'",replace
}


*** Fare 
forval yr = 2008/2017{		
	* Append yearly files
	use "$source_conf/ficusfare/fare`yr'", clear
	save "$source_conf/ficusfare/fare_`yr'",replace
}
