



*-------------------------------------------------------------------------------
* Enquete LIFI
*-------------------------------------------------------------------------------

forvalues year = 2000(1)2011 {
	foreach name in ent {
		cd "${rawdatadir}/LIFI_Enquête LIFI_`year'"
		import sas "`name'.sas7bdat", clear
		rename *, lower
		gen year = `year'	
		tempfile lifi_`name'_`year'
		save `lifi_`name'_`year''
	}
}

*-------------------------------------------------------------------------------
* LIFI - LIFI
*-------------------------------------------------------------------------------

forvalues year = 2012(1)2013 {
	foreach name in ent {
		cd "${rawdatadir}/LIFI_LIFI_`year'"
		import sas "`name'.sas7bdat", clear
		rename *, lower
		gen year = `year'		
		tempfile lifi_`name'_`year'
		save `lifi_`name'_`year''
	}
}

/*
	Careful, after 2014, the name of the datasets change
	preserve the original name
*/
forvalues year = 2014(1)2017 {
	foreach x in ul_lifi   { 
		cd "${rawdatadir}/LIFI_LIFI_`year'"
		import sas "`x'.sas7bdat", clear
		rename *, lower
		gen year = `year'
		
		if "`x'" == "liaison_lifi"{
			local name "lia"
		}
		if "`x'" == "groupe"{
			local name "tg"
		}		
		if "`x'" == "liaison_reelle"{
			local name "lar"
		}			
		if "`x'" == "ul_lifi"{
			local name "ent"
		}			
		tempfile lifi_`name'_`year'
		save `lifi_`name'_`year''
	}
}


*===============================================================================
* Append
*===============================================================================
{
	
	clear  
	forvalues year =2000(1)2017{
		append using `lifi_ent_`year''
	}

	replace sirlifi = id_ul if sirlifi == ""
	replace sirtg = id_groupe if sirtg == ""
	replace paystg = natiogr_cog if paystg == ""

	keep sirlifi sirtg contour year id_ul id_groupe paystg 
	keep if (contour == "C" | contour == "T" | year >= 2014) | !(paystg == "" | inlist(paystg,"061","61"))
	drop contour id_ul
	rename sirlifi siren
	bys sirtg year: gen nb_firmes = _n

	*We want actual groups (multiple subs. - one subs can happen if the group is foreign)
	drop if nb_firmes == 1 & (paystg == "" | inlist(paystg,"061","61"))
	drop sirtg nb_firmes paystg

	*keep only fully numeric SIREN
	* Drop siren that starts with a letter (fake code corresponding to foreign firms)
	keep if regexm(siren, "^[0-9]")==1
	compress 
	save "$temp/lifi",replace

}
*


	
